<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<title>Snake.io Premium</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
  /* Sistema de Design Moderno */
  :root {
    --primary-color: #00ff88;
    --primary-dark: #00cc66;
    --secondary-color: #00ccff;
    --secondary-dark: #0099cc;
    --accent-color: #ff4444;
    --accent-dark: #cc0000;
    --warning-color: #ffcc00;
    --warning-dark: #ff9900;
    --background-dark: #121212;
    --background-darker: #0a0a0a;
    --background-light: #1e1e1e;
    --text-primary: #ffffff;
    --text-secondary: #aaaaaa;
    --text-dark: #333333;
    --success-color: #00ff88;
    --danger-color: #ff4444;
    --info-color: #00ccff;
    --border-radius: 12px;
    --border-radius-sm: 8px;
    --box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    --box-shadow-sm: 0 2px 10px rgba(0, 0, 0, 0.2);
    --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
    --font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    -webkit-tap-highlight-color: transparent;
  }

  body, html {
    width: 100%;
    height: 100%;
    overflow: hidden;
    font-family: var(--font-family);
    color: var(--text-primary);
    background-color: var(--background-darker);
    user-select: none;
    -webkit-user-select: none;
    -webkit-touch-callout: none;
    touch-action: manipulation;
  }

  /* Loader */
  .loader {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: var(--background-darker);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    gap: 20px;
  }
  
  .loader-spinner {
    width: 60px;
    height: 60px;
    border: 5px solid rgba(0, 255, 136, 0.2);
    border-radius: 50%;
    border-top-color: var(--primary-color);
    animation: spin 1.2s ease-in-out infinite;
  }
  
  .loader-text {
    color: var(--text-primary);
    font-size: 1.2rem;
    font-weight: 500;
    text-align: center;
    max-width: 80%;
  }

  .loader-progress {
    width: 200px;
    height: 6px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 3px;
    overflow: hidden;
    margin-top: 10px;
  }

  .loader-progress-bar {
    height: 100%;
    background: var(--primary-color);
    width: 0%;
    transition: width 0.3s ease;
  }
  
  @keyframes spin {
    to { transform: rotate(360deg); }
  }

  /* Container Principal */
  #app-container {
    width: 100%;
    height: 100%;
    position: relative;
    overflow: hidden;
    display: flex;
    flex-direction: column;
  }

  /* Efeito de Estrelas */
  .stars {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: 0;
  }

  .star {
    position: absolute;
    background-color: white;
    border-radius: 50%;
    animation: twinkle var(--duration, 5s) infinite ease-in-out;
    opacity: var(--opacity, 0.7);
  }

  @keyframes twinkle {
    0%, 100% { transform: scale(1); opacity: 0.2; }
    50% { transform: scale(1.05); opacity: 1; }
    100% { transform: scale(1); opacity: 0.8; }
  }

  /* Sistema de Camadas */
  .layer {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
  }

  /* Container do Jogo */
  #gameContainer {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    background: radial-gradient(ellipse at center, #1a1a2e 0%, #16213e 100%);
    z-index: 10;
  }

  canvas#gameCanvas {
    display: block;
    width: 100%;
    height: 100%;
    touch-action: none;
  }
  
  /* Camada de Efeitos */
  #effectsLayer {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: 20;
  }

  /* HUD Moderno */
  .hud {
    position: absolute;
    background: rgba(0, 0, 0, 0.7);
    border-radius: var(--border-radius);
    padding: 12px 16px;
    font-weight: 600;
    font-size: 1.1rem;
    display: flex;
    align-items: center;
    gap: 8px;
    box-shadow: var(--box-shadow);
    backdrop-filter: blur(5px);
    -webkit-backdrop-filter: blur(5px);
    pointer-events: auto;
    transition: var(--transition);
    z-index: 100;
  }

  .hud:hover {
    background: rgba(0, 0, 0, 0.8);
  }

  #hudScore {
    top: 20px;
    right: 20px;
    color: var(--primary-color);
  }

  #hudTime {
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    color: var(--secondary-color);
  }

  /* Controles */
  #controls {
    position: absolute;
    bottom: 20px;
    left: 20px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    pointer-events: auto;
    z-index: 100;
  }

  .control-btn {
    width: 55px;
    height: 55px;
    border-radius: 50%;
    background: rgba(0, 0, 0, 0.6);
    border: 2px solid var(--primary-color);
    color: var(--primary-color);
    font-size: 1.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: var(--transition);
    box-shadow: var(--box-shadow);
    user-select: none;
  }

  .control-btn:active {
    transform: scale(0.95);
    background: rgba(0, 255, 136, 0.2);
  }

  #btnPause {
    position: absolute;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    width: 60px;
    height: 60px;
    font-size: 1.8rem;
  }

  /* Controles touch */
  #touchControls {
    position: absolute;
    bottom: 20px;
    right: 20px;
    width: 140px;
    height: 140px;
    pointer-events: none;
    z-index: 100;
    display: none;
  }

  .touch-zone {
    position: absolute;
    width: 50%;
    height: 50%;
    opacity: 0.3;
    pointer-events: auto;
    transition: opacity 0.2s ease;
    background-color: var(--primary-color);
  }

  .touch-zone:active {
    opacity: 0.5;
  }

  #touchUp {
    top: 0;
    left: 25%;
    border-top-left-radius: 50%;
    border-top-right-radius: 50%;
  }

  #touchRight {
    top: 25%;
    right: 0;
    border-top-right-radius: 50%;
    border-bottom-right-radius: 50%;
  }

  #touchDown {
    bottom: 0;
    left: 25%;
    border-bottom-left-radius: 50%;
    border-bottom-right-radius: 50%;
  }

  #touchLeft {
    top: 25%;
    left: 0;
    border-top-left-radius: 50%;
    border-bottom-left-radius: 50%;
  }

  /* Painéis e Modais */
  .panel {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.9);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    z-index: 1000;
    padding: 20px;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
  }

  .panel.active {
    opacity: 1;
    pointer-events: all;
  }

  .panel-content {
    max-width: 800px;
    width: 90%;
    max-height: 90vh;
    background: var(--background-dark);
    border-radius: var(--border-radius);
    padding: 30px;
    box-shadow: var(--box-shadow);
    border: 1px solid rgba(0, 255, 136, 0.1);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    transform: translateY(20px);
    transition: transform 0.3s ease;
  }

  .panel.active .panel-content {
    transform: translateY(0);
  }

  .panel-header {
    margin-bottom: 20px;
    text-align: center;
    position: relative;
  }

  .panel-header::after {
    content: '';
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    width: 80px;
    height: 3px;
    background: var(--primary-color);
    border-radius: 3px;
  }

  .panel-title {
    font-size: 2.2rem;
    margin-bottom: 10px;
    color: var(--primary-color);
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: 700;
    text-shadow: 0 0 10px rgba(0, 255, 136, 0.5);
  }

  .panel-subtitle {
    font-size: 1rem;
    color: var(--text-secondary);
    margin-bottom: 20px;
    font-weight: 400;
  }

  .panel-body {
    flex: 1;
    overflow-y: auto;
    padding: 10px 5px 10px 0;
    margin: 10px 0;
  }

  .panel-footer {
    margin-top: 20px;
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 10px;
  }

  /* Botões */
  .btn {
    background: var(--primary-color);
    color: var(--text-dark);
    border: none;
    padding: 15px 30px;
    font-size: 1rem;
    border-radius: var(--border-radius);
    cursor: pointer;
    font-weight: 600;
    transition: var(--transition);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    box-shadow: var(--box-shadow);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    min-width: 200px;
    position: relative;
    overflow: hidden;
  }

  .btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
    transition: 0.5s;
  }

  .btn:hover {
    background: var(--primary-dark);
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(0, 255, 136, 0.3);
  }

  .btn:hover::before {
    left: 100%;
  }

  .btn:active {
    transform: translateY(0);
  }

  .btn-secondary {
    background: transparent;
    color: var(--primary-color);
    border: 2px solid var(--primary-color);
  }

  .btn-secondary:hover {
    background: rgba(0, 255, 136, 0.1);
  }

  .btn-danger {
    background: var(--danger-color);
    color: white;
  }

  .btn-danger:hover {
    background: var(--accent-dark);
  }

  .btn-small {
    padding: 10px 20px;
    font-size: 0.9rem;
    min-width: auto;
  }

  /* Cards - COM ÍCONES */
  .card {
    background: var(--background-light);
    border-radius: var(--border-radius);
    padding: 20px;
    box-shadow: var(--box-shadow-sm);
    margin-bottom: 15px;
  }

  .card-title {
    font-size: 1.2rem;
    color: var(--primary-color);
    margin-bottom: 10px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 10px;
  }

  /* Formulários */
  .form-group {
    margin-bottom: 15px;
  }

  .form-label {
    display: block;
    margin-bottom: 8px;
    color: var(--text-secondary);
    font-size: 0.9rem;
    font-weight: 500;
  }

  .form-control {
    width: 100%;
    padding: 12px 15px;
    border-radius: var(--border-radius-sm);
    border: 1px solid rgba(255, 255, 255, 0.1);
    background: rgba(0, 0, 0, 0.3);
    color: var(--text-primary);
    font-family: var(--font-family);
    font-size: 1rem;
    transition: var(--transition);
  }

  .form-control:focus {
    outline: none;
    border-color: var(--primary-color);
    box-shadow: 0 0 0 2px rgba(0, 255, 136, 0.2);
  }

  /* Seção de Login/Cadastro */
  .auth-container {
    max-width: 400px;
    width: 90%;
    margin: 0 auto;
  }

  .auth-tabs {
    display: flex;
    margin-bottom: 20px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  }

  .auth-tab {
    padding: 10px 20px;
    cursor: pointer;
    font-weight: 500;
    color: var(--text-secondary);
    border-bottom: 2px solid transparent;
    transition: var(--transition);
  }

  .auth-tab.active {
    color: var(--primary-color);
    border-bottom-color: var(--primary-color);
  }

  .auth-content {
    display: none;
  }

  .auth-content.active {
    display: block;
  }

  /* Seção de Saldo */
  .balance-display {
    text-align: center;
    margin: 20px 0;
    padding: 15px;
    background: rgba(0, 0, 0, 0.3);
    border-radius: var(--border-radius);
    border: 1px solid rgba(0, 255, 136, 0.2);
  }

  .balance-amount {
    font-size: 2rem;
    color: var(--primary-color);
    font-weight: 700;
    margin: 10px 0;
  }

  .balance-label {
    font-size: 0.9rem;
    color: var(--text-secondary);
  }

  /* Seção de Saque */
  .withdraw-form {
    display: flex;
    flex-direction: column;
    gap: 15px;
  }

  .payment-method {
    margin-top: 20px;
    font-size: 1.1rem;
    color: var(--primary-color);
  }

  .payment-details {
    margin-top: 15px;
    padding: 15px;
    background: rgba(0, 0, 0, 0.2);
    border-radius: var(--border-radius-sm);
    border-left: 3px solid var(--primary-color);
  }

  /* Seção de Perfil */
  .profile-header {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 20px;
  }

  .profile-avatar {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: var(--primary-color);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: var(--text-dark);
    font-weight: 700;
  }

  .profile-info h3 {
    font-size: 1.2rem;
    margin-bottom: 5px;
  }

  .profile-info p {
    color: var(--text-secondary);
    font-size: 0.9rem;
  }

  .stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
    margin-bottom: 20px;
  }

  .stat-item {
    background: rgba(0, 0, 0, 0.3);
    padding: 15px;
    border-radius: var(--border-radius-sm);
    text-align: center;
  }

  .stat-value {
    font-size: 1.5rem;
    color: var(--primary-color);
    font-weight: 700;
    margin-bottom: 5px;
  }

  .stat-label {
    font-size: 0.8rem;
    color: var(--text-secondary);
  }

  /* Notificações */
  .notification {
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(0, 0, 0, 0.9);
    color: white;
    padding: 15px 25px;
    border-radius: var(--border-radius);
    z-index: 2000;
    opacity: 0;
    transition: opacity 0.3s ease, transform 0.3s ease;
    display: flex;
    align-items: center;
    gap: 10px;
    box-shadow: var(--box-shadow);
    border-left: 4px solid var(--primary-color);
    max-width: 90%;
    text-align: center;
    transform: translate(-50%, -20px);
  }

  .notification.show {
    opacity: 1;
    transform: translate(-50%, 0);
  }

  .notification.success {
    border-left-color: var(--success-color);
  }

  .notification.warning {
    border-left-color: var(--warning-color);
  }

  .notification.danger {
    border-left-color: var(--danger-color);
  }

  .notification.info {
    border-left-color: var(--info-color);
  }

  /* Efeitos de Animação */
  @keyframes pulse {
    0%, 100% { transform: scale(1); opacity: 0.8; }
    50% { transform: scale(1.05); opacity: 1; }
    100% { transform: scale(1); opacity: 0.8; }
  }

  .pulse {
    animation: pulse 2s infinite;
  }

  @keyframes float {
    0% { transform: translateY(0px); }
    50% { transform: translateY(-10px); }
    100% { transform: translateY(0px); }
  }

  .float {
    animation: float 3s ease-in-out infinite;
  }

  @keyframes glow {
    0% { box-shadow: 0 0 5px currentColor; }
    50% { box-shadow: 0 0 20px currentColor; }
    100% { box-shadow: 0 0 5px currentColor; }
  }

  .glow {
    animation: glow 2s infinite;
  }

  /* Scrollbar */
  ::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }

  ::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.05);
    border-radius: 10px;
  }

  ::-webkit-scrollbar-thumb {
    background: var(--primary-color);
    border-radius: 10px;
  }

  ::-webkit-scrollbar-thumb:hover {
    background: var(--primary-dark);
  }

  /* Responsividade */
  @media (max-width: 768px) {
    .panel-content {
      padding: 20px;
      width: 95%;
    }

    .panel-title {
      font-size: 1.8rem;
    }

    .btn {
      padding: 12px 20px;
      min-width: 160px;
      width: 100%;
    }

    .hud {
      font-size: 1rem;
      padding: 8px 12px;
    }

    .control-btn {
      width: 45px;
      height: 45px;
      font-size: 1.4rem;
    }

    #btnPause {
      width: 55px;
      height: 55px;
      font-size: 1.6rem;
    }

    .stats-grid {
      grid-template-columns: 1fr;
    }
  }

  /* Ajustes para mobile */
  @media (max-width: 480px) {
    #touchControls {
      width: 120px;
      height: 120px;
    }

    .control-btn {
      width: 40px;
      height: 40px;
      font-size: 1.2rem;
    }

    #btnPause {
      width: 50px;
      height: 50px;
      font-size: 1.5rem;
    }
  }

  /* Tabela de competição */
  .competition-table {
    width: 100%;
    border-collapse: collapse;
    margin: 15px 0;
    white-space: nowrap;
    background: var(--background-light); /* Fundo escuro para tabela */
    color: var(--text-primary); /* Texto claro */
  }

  .competition-table th, 
  .competition-table td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .competition-table th {
    background: rgba(0, 0, 0, 0.3);
    color: var(--primary-color);
    font-weight: 600;
  }

  .competition-table tr:hover {
    background: rgba(0, 0, 0, 0.2);
  }

  .position-1 {
    color: #ffcc00;
    font-weight: 700;
  }

  .position-2 {
    color: #cccccc;
    font-weight: 600;
  }

  .position-3 {
    color: #cd7f32;
    font-weight: 600;
  }

  .position-prize {
    color: var(--success-color);
    font-weight: 600;
  }

  .waiting-message {
    text-align: center;
    padding: 20px;
    color: var(--text-secondary);
    font-size: 1.1rem;
  }

  .progress-container {
    width: 100%;
    background: rgba(0, 0, 0, 0.3);
    border-radius: 5px;
    margin: 15px 0;
    overflow: hidden;
  }

  .progress-bar {
    height: 10px;
    background: var(--primary-color);
    width: 0%;
    transition: width 0.3s ease;
  }

  .players-count {
    text-align: center;
    font-size: 1.2rem;
    margin: 10px 0;
  }

  /* Botões de anúncio */
  .ad-btn {
    background: linear-gradient(135deg, #ffcc00, #ff9900);
    color: #222;
    border: none;
    border-radius: 50px;
    padding: 12px 25px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(255, 153, 0, 0.3);
    margin: 10px auto;
  }

  .ad-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 20px rgba(255, 153, 0, 0.4);
  }

  .ad-btn:active {
    transform: translateY(1px);
  }

  .ad-btn i {
    font-size: 1.2em;
  }

  /* Histórico de competições */
  .history-entry {
    background: rgba(255, 255, 255, 0.05);
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .history-date {
    font-size: 0.9rem;
    color: var(--text-secondary);
  }

  .history-position {
    font-weight: 700;
    font-size: 1.2rem;
    color: var(--primary-color);
  }

  .history-prize {
    color: var(--warning-color);
    font-weight: 600;
  }
  
  /* Nova seção de resultados pendentes */
  .pending-results {
    background: rgba(0, 0, 0, 0.3);
    border-radius: var(--border-radius-sm);
    padding: 15px;
    margin-top: 15px;
    border-left: 3px solid var(--warning-color);
  }

  .pending-title {
    color: var(--warning-color);
    font-weight: 600;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .pending-message {
    color: var(--text-secondary);
    font-size: 0.9rem;
    margin-bottom: 10px;
  }
  
  .completed-results {
    background: rgba(0, 0, 0, 0.3);
    border-radius: var(--border-radius-sm);
    padding: 15px;
    margin-top: 15px;
    border-left: 3px solid var(--success-color);
  }

  .completed-title {
    color: var(--success-color);
    font-weight: 600;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
  }
  
  .competition-tabs {
    display: flex;
    margin-bottom: 15px;
    gap: 10px;
  }
  
  .competition-tab {
    flex: 1;
    text-align: center;
    padding: 10px;
    background: rgba(0, 0, 0, 0.3);
    border-radius: var(--border-radius-sm);
    cursor: pointer;
    transition: all 0.3s ease;
  }
  
  .competition-tab.active {
    background: var(--primary-color);
    color: var(--text-dark);
    font-weight: 600;
  }
  
  .competition-content {
    display: none;
  }
  
  .competition-content.active {
    display: block;
  }

  /* Botão de login com Google */
  .google-btn {
    background: #4285F4;
    color: white;
    border: none;
    padding: 12px 20px;
    font-size: 1rem;
    border-radius: var(--border-radius);
    cursor: pointer;
    font-weight: 600;
    transition: var(--transition);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    width: 100%;
    margin: 10px 0;
  }

  .google-btn:hover {
    background: #3367D6;
  }

  .google-btn i {
    font-size: 1.2em;
  }

  /* Botão de convidado */
  .guest-btn {
    background: var(--secondary-color);
    color: var(--text-dark);
    border: none;
    padding: 12px 20px;
    font-size: 1rem;
    border-radius: var(--border-radius);
    cursor: pointer;
    font-weight: 600;
    transition: var(--transition);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    width: 100%;
    margin: 10px 0;
  }

  .guest-btn:hover {
    background: var(--secondary-dark);
  }
  
  /* Resultados da competição */
  .results-table-container {
    max-height: 300px;
    overflow-y: auto;
    margin-top: 15px;
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: var(--border-radius-sm);
    padding: 10px;
    overflow-x: auto;
  }
  
  /* Painel de competição em tempo real */
  .live-competition-panel {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: var(--background-dark); /* Fundo escuro */
    border-radius: var(--border-radius);
    padding: 20px;
    width: 90%;
    max-width: 600px;
    max-height: 80vh;
    overflow-y: auto;
    z-index: 2000;
    box-shadow: var(--box-shadow);
    border: 2px solid var(--primary-color);
    color: var(--text-primary); /* Texto claro */
  }
  
  .live-competition-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  }
  
  .live-competition-title {
    font-size: 1.5rem;
    color: var(--primary-color);
    font-weight: 700;
  }
  
  .live-competition-close {
    background: transparent;
    border: none;
    color: var(--text-secondary);
    font-size: 1.5rem;
    cursor: pointer;
  }
  
  .live-competition-body {
    margin-bottom: 15px;
  }
  
  .live-competition-footer {
    display: flex;
    justify-content: flex-end;
  }
  
  .live-player-you {
    background: rgba(0, 255, 136, 0.1);
    border-left: 3px solid var(--primary-color);
  }

  /* Painel de Anúncios */
  .ad-panel {
    text-align: center;
  }

  .ad-container {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
    margin: 20px 0;
  }

  .ad-item {
    background: rgba(255, 255, 255, 0.05);
    border-radius: var(--border-radius);
    padding: 15px;
    cursor: pointer;
    transition: all 0.3s ease;
  }

  .ad-item:hover {
    background: rgba(255, 255, 255, 0.1);
    transform: translateY(-5px);
  }

  .ad-number {
    font-size: 2rem;
    color: var(--primary-color);
    font-weight: 700;
    margin-bottom: 10px;
  }

  .ad-text {
    font-size: 0.9rem;
    color: var(--text-secondary);
  }

  /* Barra de status */
  .status-bar {
    display: flex;
    justify-content: space-between;
    padding: 10px 15px;
    background: rgba(0, 0, 0, 0.3);
    border-radius: var(--border-radius-sm);
    margin-bottom: 15px;
    font-size: 0.9rem;
  }
  
  /* Barra de menu estilo Instagram */
  .bottom-navbar {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background: rgba(30, 30, 30, 0.95);
    backdrop-filter: blur(10px);
    display: flex;
    justify-content: space-around;
    padding: 10px 0;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    z-index: 1000;
    display: flex;
  }
  
  .nav-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    color: var(--text-secondary);
    text-decoration: none;
    font-size: 0.7rem;
    transition: color 0.3s;
    cursor: pointer;
  }
  
  .nav-item.active {
    color: var(--primary-color);
  }
  
  .nav-item i {
    font-size: 1.5rem;
    margin-bottom: 4px;
  }
  
  /* Seções de tela cheia */
  .section {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    padding: 20px;
    overflow-y: auto;
    z-index: 900;
    display: none;
    background: var(--background-darker);
  }
  
  .section.active {
    display: block;
  }
  
  /* Ajustes de layout para preencher tela */
  .full-screen-section {
    padding-bottom: 70px;
  }
  
  /* Ajustes para o jogo em tela cheia */
  .game-full-screen {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    z-index: 1000;
  }
  
  /* Efeitos visuais */
  .death-effect {
    position: absolute;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(255,0,0,0.8) 0%, rgba(255,0,0,0) 70%);
    transform: scale(0);
    animation: deathEffect 0.8s ease-out forwards;
  }
  
  .grow-effect {
    position: absolute;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(0,255,136,0.5) 0%, rgba(0,255,136,0) 70%);
    transform: scale(0);
    animation: growEffect 0.5s ease-out forwards;
  }
  
  @keyframes deathEffect {
    0% { transform: scale(0); opacity: 0.8; }
    100% { transform: scale(3); opacity: 0; }
  }
  
  @keyframes growEffect {
    0% { transform: scale(0); opacity: 0.8; }
    100% { transform: scale(3); opacity: 0; }
  }
  
  /* Contador regressivo */
  .countdown-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 3000;
    font-size: 20vw;
    font-weight: bold;
    color: var(--primary-color);
    text-shadow: 0 0 20px rgba(0, 255, 136, 0.7);
  }
  
  /* Botão Jogar */
  #btnStartGame {
    display: none;
    margin-top: 15px;
    background: linear-gradient(135deg, #00ff88, #00cc66);
    animation: pulse 1.5s infinite;
  }
</style>
</head>
<body>
<!-- Loader -->
<div id="loader" class="loader">
  <div class="loader-spinner"></div>
  <div class="loader-text">Carregando Snake.io Premium...</div>
  <div class="loader-progress">
    <div id="loaderProgress" class="loader-progress-bar"></div>
  </div>
</div>

<!-- Efeito de Estrelas -->
<div class="stars" id="stars"></div>

<!-- Container Principal -->
<div id="app-container">
  <!-- Tela de Login/Cadastro -->
  <div id="authPanel" class="panel active">
    <div class="panel-content">
      <div class="panel-header">
        <h1 class="panel-title">🐍 Snake.io</h1>
        <p class="panel-subtitle">Jogue, ganhe pontos e acumule prêmios!</p>
      </div>
      <div class="panel-body">
        <div class="auth-container">
          <div class="auth-tabs">
            <div class="auth-tab active" data-tab="login">Entrar</div>
            <div class="auth-tab" data-tab="register">Cadastrar</div>
          </div>

          <div id="loginContent" class="auth-content active">
            <form id="loginForm">
              <div class="form-group">
                <label for="loginEmail" class="form-label">E-mail</label>
                <input type="email" id="loginEmail" class="form-control" placeholder="seu@email.com" required>
              </div>
              <div class="form-group">
                <label for="loginPassword" class="form-label">Senha</label>
                <input type="password" id="loginPassword" class="form-control" placeholder="••••••••" required>
              </div>
              
              <button type="submit" class="btn">Entrar</button>
              
              <div class="divider" style="text-align: center; margin: 20px 0; color: var(--text-secondary);">OU</div>
              
              <button type="button" class="google-btn" id="googleLoginBtn">
                <i class="fab fa-google"></i> Entrar com Google
              </button>
              
              <button type="button" class="guest-btn" id="guestLoginBtn">
                <i class="fas fa-user-secret"></i> Jogar como Convidado
              </button>
            </form>
          </div>

          <div id="registerContent" class="auth-content">
            <form id="registerForm">
              <div class="form-group">
                <label for="registerName" class="form-label">Nome</label>
                <input type="text" id="registerName" class="form-control" placeholder="Seu nome" required>
              </div>
              <div class="form-group">
                <label for="registerEmail" class="form-label">E-mail</label>
                <input type="email" id="registerEmail" class="form-control" placeholder="seu@email.com" required>
              </div>
              <div class="form-group">
                <label for="registerPassword" class="form-label">Senha</label>
                <input type="password" id="registerPassword" class="form-control" placeholder="••••••••" required>
              </div>
              <div class="form-group">
                <label for="registerConfirmPassword" class="form-label">Confirmar Senha</label>
                <input type="password" id="registerConfirmPassword" class="form-control" placeholder="••••••••" required>
              </div>
              
              <button type="submit" class="btn">Cadastrar</button>
              
              <div class="divider" style="text-align: center; margin: 20px 0; color: var(--text-secondary);">OU</div>
              
              <button type="button" class="google-btn" id="googleRegisterBtn">
                <i class="fab fa-google"></i> Cadastrar com Google
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Menu Principal -->
  <div id="mainMenu" class="section full-screen-section">
    <div class="panel-content">
      <div class="panel-header">
        <h1 class="panel-title">🐍 Snake.io</h1>
        <p class="panel-subtitle">Bem-vindo, <span id="userName">Jogador</span>!</p>
      </div>
      <div class="panel-body" style="max-height: calc(100vh - 250px); overflow-y: auto;">
        <!-- Barra de status -->
        <div class="status-bar">
          <div>Nível: <span id="statusLevel">1</span></div>
          <div>Saldo: R$ <span id="statusBalance">0.00</span></div>
        </div>

        <div class="balance-display">
          <div class="balance-label">Seu Saldo</div>
          <div class="balance-amount">R$ <span id="saldoDisplay">0.00</span></div>
        </div>

        <div class="card">
          <div class="card-title">💰 Estatísticas</div>
          <div class="stats-grid">
            <div class="stat-item">
              <div class="stat-value" id="totalGames">0</div>
              <div class="stat-label">Partidas</div>
            </div>
            <div class="stat-item">
              <div class="stat-value" id="highScore">0</div>
              <div class="stat-label">Recorde</div>
            </div>
            <div class="stat-item">
              <div class="stat-value" id="totalEarnings">0.00</div>
              <div class="stat-label">Ganhos</div>
            </div>
            <div class="stat-item">
              <div class="stat-value" id="totalWithdraws">0.00</div>
              <div class="stat-label">Saques</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Painel de Perfil -->
  <div id="profilePanel" class="section full-screen-section">
    <div class="panel-content">
      <div class="panel-header">
        <h1 class="panel-title">👤 Perfil</h1>
        <p class="panel-subtitle">Suas informações e configurações</p>
      </div>
      <div class="panel-body" style="max-height: calc(100vh - 250px); overflow-y: auto;">
        <div class="profile-header">
          <div class="profile-avatar" id="profileAvatar">J</div>
          <div class="profile-info">
            <h3 id="profileUserName">Jogador</h3>
            <p id="profileUserEmail">email@exemplo.com</p>
          </div>
        </div>
        
        <div class="balance-display">
          <div class="balance-label">Seu Saldo</div>
          <div class="balance-amount">R$ <span id="profileBalance">0.00</span></div>
        </div>
        
        <div class="card">
          <div class="card-title">📊 Estatísticas do Jogador</div>
          <div class="stats-grid">
            <div class="stat-item">
              <div class="stat-value" id="profileTotalGames">0</div>
              <div class="stat-label">Partidas</div>
            </div>
            <div class="stat-item">
              <div class="stat-value" id="profileHighScore">0</div>
              <div class="stat-label">Recorde</div>
            </div>
            <div class="stat-item">
              <div class="stat-value" id="profileTotalEarnings">0.00</div>
              <div class="stat-label">Ganhos</div>
            </div>
            <div class="stat-item">
              <div class="stat-value" id="profileTotalWithdraws">0.00</div>
              <div class="stat-label">Saques</div>
            </div>
          </div>
        </div>
      </div>
      <div class="panel-footer">
        <button id="btnLogout" class="btn btn-danger">SAIR</button>
      </div>
    </div>
  </div>

  <!-- Painel de Anúncios -->
  <div id="adPanel" class="panel">
    <div class="panel-content">
      <div class="panel-header">
        <h1 class="panel-title">Assista aos Anúncios</h1>
        <p class="panel-subtitle">Clique nos botões abaixo para assistir aos anúncios</p>
      </div>
      <div class="panel-body ad-panel">
        <div class="ad-container">
          <div class="ad-item" data-ad="1">
            <div class="ad-number">1</div>
            <div class="ad-text">Clique para assistir</div>
          </div>
          <div class="ad-item" data-ad="2">
            <div class="ad-number">2</div>
            <div class="ad-text">Clique para assistir</div>
          </div>
          <div class="ad-item" data-ad="3">
            <div class="ad-number">3</div>
            <div class="ad-text">Clique para assistir</div>
          </div>
          <div class="ad-item" data-ad="4">
            <div class="ad-number">4</div>
            <div class="ad-text">Clique para assistir</div>
          </div>
        </div>
      </div>
      <div class="panel-footer">
        <p id="adStatus">Aguardando anúncios... (0/4)</p>
        <!-- Botão Jogar que só aparece após 4 anúncios -->
        <button id="btnStartGame" class="btn">JOGAR</button>
      </div>
    </div>
  </div>

  <!-- Container do Jogo -->
  <div id="gameContainer" class="game-full-screen" style="display: none;">
    <!-- Camada de efeitos visuais -->
    <div id="effectsLayer"></div>
    
    <!-- Canvas do Jogo -->
    <canvas id="gameCanvas"></canvas>
    
    <!-- HUD -->
    <div id="hudScore" class="hud">🏆 <span id="scoreDisplay">0</span></div>
    <div id="hudTime" class="hud">⏱️ <span id="timeDisplay">25s</span></div>
    
    <!-- Controles -->
    <div id="controls">
      <button id="btnPause" class="control-btn">⏸️</button>
    </div>
    
    <!-- Controles Touch -->
    <div id="touchControls">
      <div id="touchUp" class="touch-zone" data-direction="up"></div>
      <div id="touchRight" class="touch-zone" data-direction="right"></div>
      <div id="touchDown" class="touch-zone" data-direction="down"></div>
      <div id="touchLeft" class="touch-zone" data-direction="left"></div>
    </div>
  </div>

  <!-- Painel de Pause -->
  <div id="pausePanel" class="panel">
    <div class="panel-content">
      <div class="panel-header">
        <h1 class="panel-title">⏸️ Jogo Pausado</h1>
        <p class="panel-subtitle">Partida em andamento</p>
      </div>
      <div class="panel-body" style="text-align: center;">
        <div class="balance-display" style="margin: 20px auto;">
          <div class="balance-label">Pontuação Atual</div>
          <div class="balance-amount"><span id="pauseScore">0</span></div>
        </div>
        <p style="font-size: 1.2rem; margin-bottom: 20px;">Tempo restante: <span id="pauseTime">25s</span></p>
      </div>
      <div class="panel-footer">
        <button id="btnResume" class="btn">▶ Continuar</button>
        <button id="btnQuit" class="btn btn-danger">🚪 Sair</button>
      </div>
    </div>
  </div>

  <!-- Painel de Game Over -->
  <div id="gameOverPanel" class="panel">
    <div class="panel-content">
      <div class="panel-header">
        <h1 class="panel-title">💀 Game Over</h1>
        <p class="panel-subtitle">Sua partida terminou</p>
      </div>
      <div class="panel-body" style="text-align: center;">
        <div class="balance-display" style="margin: 20px auto;">
          <div class="balance-label">Pontuação Final</div>
          <div class="balance-amount"><span id="finalScore">0</span></div>
        </div>
      </div>
      <div class="panel-footer">
        <button id="btnBackToMenu" class="btn">🏠 Menu Principal</button>
      </div>
    </div>
  </div>

  <!-- Painel de Saque -->
  <div id="withdrawPanel" class="section full-screen-section">
    <div class="panel-content">
      <div class="panel-header">
        <h1 class="panel-title">💵 Solicitar Saque</h1>
        <p class="panel-subtitle">Saldo disponível: R$ <span id="withdrawBalance">0.00</span></p>
      </div>
      <div class="panel-body">
        <form id="withdrawForm" class="withdraw-form">
          <div class="form-group">
            <label for="withdrawAmount" class="form-label">Valor do Saque (mínimo R$ 5,00)</label>
            <input type="number" id="withdrawAmount" class="form-control" min="5" step="0.01" placeholder="5.00" required>
          </div>
          
          <div class="form-group">
            <label for="withdrawMethod" class="form-label">Método de Pagamento</label>
            <select id="withdrawMethod" class="form-control" required>
              <option value="">Selecione...</option>
              <option value="pix">PIX</option>
              <option value="paypal">PayPal</option>
              <option value="bank">Transferência Bancária</option>
            </select>
          </div>
          
          <div id="pixFields" class="payment-details" style="display: none;">
            <div class="form-group">
              <label for="pixKey" class="form-label">Chave PIX</label>
              <input type="text" id="pixKey" class="form-control" placeholder="Chave PIX (CPF, e-mail, telefone)">
            </div>
          </div>
          
          <div id="paypalFields" class="payment-details" style="display: none;">
            <div class="form-group">
              <label for="paypalEmail" class="form-label">E-mail PayPal</label>
              <input type="email" id="paypalEmail" class="form-control" placeholder="seu@email.com">
            </div>
          </div>
          
          <div id="bankFields" class="payment-details" style="display: none;">
            <div class="form-group">
              <label for="bankName" class="form-label">Banco</label>
              <input type="text" id="bankName" class="form-control" placeholder="Nome do Banco">
            </div>
            
            <div class="form-group">
              <label for="accountType" class="form-label">Tipo de Conta</label>
              <select id="accountType" class="form-control">
                <option value="checking">Conta Corrente</option>
                <option value="savings">Conta Poupança</option>
              </select>
            </div>
            
            <div class="form-group">
              <label for="accountNumber" class="form-label">Número da Conta</label>
              <input type="text" id="accountNumber" class="form-control" placeholder="Número da Conta">
            </div>
            
            <div class="form-group">
              <label for="agencyNumber" class="form-label">Agência</label>
              <input type="text" id="agencyNumber" class="form-control" placeholder="Número da Agência">
            </div>
            
            <div class="form-group">
              <label for="accountHolder" class="form-label">Titular da Conta</label>
              <input type="text" id="accountHolder" class="form-control" placeholder="Nome do Titular">
            </div>
            
            <div class="form-group">
              <label for="cpf" class="form-label">CPF do Titular</label>
              <input type="text" id="cpf" class="form-control" placeholder="CPF">
            </div>
          </div>
        </form>
      </div>
      <div class="panel-footer">
        <button id="btnSubmitWithdraw" class="btn">Solicitar Saque</button>
        <button id="btnCancelWithdraw" class="btn btn-secondary">Voltar</button>
      </div>
    </div>
  </div>

  <!-- Painel de Histórico de Competições -->
  <div id="historyPanel" class="section full-screen-section">
    <div class="panel-content">
      <div class="panel-header">
        <h1 class="panel-title">📜 Histórico de Competições</h1>
        <p class="panel-subtitle">Suas participações em competições</p>
      </div>
      <div class="panel-body" style="max-height: calc(100vh - 250px); overflow-y: auto;">
        <div class="competition-tabs">
          <div class="competition-tab active" data-tab="completed">Concluídas</div>
          <div class="competition-tab" data-tab="pending">Pendentes</div>
        </div>
        
        <div id="completedCompetitions" class="competition-content active">
          <h3 style="margin-bottom: 15px; text-align: center;">Competições Concluídas</h3>
          <div id="completedHistoryList">
            <!-- Histórico será preenchido aqui -->
          </div>
        </div>
        
        <div id="pendingCompetitions" class="competition-content">
          <h3 style="margin-bottom: 15px; text-align: center;">Competições Pendentes</h3>
          <div id="pendingHistoryList">
            <!-- Histórico será preenchido aqui -->
          </div>
        </div>
      </div>
      <div class="panel-footer">
        <button id="btnBackFromHistory" class="btn">Voltar</button>
      </div>
    </div>
  </div>
  
  <!-- Painel de Resultados -->
  <div id="resultsPanel" class="panel">
    <div class="panel-content">
      <div class="panel-header">
        <h1 class="panel-title">🏆 Resultados da Competição</h1>
        <p class="panel-subtitle">Classificação final</p>
      </div>
      <div class="panel-body">
        <div id="resultsInfo" style="text-align: center; margin-bottom: 20px;">
          <p>Data: <span id="resultDate">--/--/----</span></p>
          <p>Sua posição: <span id="userPosition" class="history-position">-</span></p>
          <p>Prêmio: R$ <span id="userPrize" class="history-prize">0.00</span></p>
        </div>
        
        <h3 style="text-align: center; margin-bottom: 15px;">Classificação</h3>
        <div class="results-table-container">
          <table class="competition-table">
            <thead>
              <tr>
                <th>Posição</th>
                <th>Jogador</th>
                <th>Pontos</th>
                <th>Prêmio</th>
              </tr>
            </thead>
            <tbody id="resultsTable">
              <!-- Conteúdo será preenchido via JS -->
            </tbody>
          </table>
        </div>
      </div>
      <div class="panel-footer">
        <button id="btnCloseResults" class="btn">Fechar</button>
      </div>
    </div>
  </div>
  
  <!-- Barra de navegação estilo Instagram -->
  <div class="bottom-navbar" id="bottomNavbar">
    <div class="nav-item active" data-target="mainMenu">
      <i class="fas fa-home"></i>
      <span>Início</span>
    </div>
    <div class="nav-item" data-target="gameContainer">
      <i class="fas fa-play-circle"></i>
      <span>Jogar</span>
    </div>
    <div class="nav-item" data-target="historyPanel">
      <i class="fas fa-history"></i>
      <span>Histórico</span>
    </div>
    <div class="nav-item" data-target="withdrawPanel">
      <i class="fas fa-wallet"></i>
      <span>Saque</span>
    </div>
    <div class="nav-item" data-target="profilePanel">
      <i class="fas fa-user"></i>
      <span>Perfil</span>
    </div>
  </div>
</div>

<!-- Notificações -->
<div id="notification" class="notification"></div>

<!-- Painel de Competição em Tempo Real -->
<div id="liveCompetitionPanel" class="live-competition-panel" style="display: none;">
  <div class="live-competition-header">
    <h2 class="live-competition-title">🏆 Competição Ativa</h2>
    <button id="btnCloseLiveCompetition" class="live-competition-close">&times;</button>
  </div>
  <div class="live-competition-body">
    <div class="players-count">
      Jogadores: <span id="livePlayersCount">0</span>/10
    </div>
    <div class="progress-container">
      <div id="livePlayersProgress" class="progress-bar" style="width: 0%"></div>
    </div>
    
    <h3 style="text-align: center; margin: 15px 0;">Participantes</h3>
    <div class="results-table-container">
      <table class="competition-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Jogador</th>
            <th>Pontos</th>
            <th>Prêmio</th>
          </tr>
        </thead>
        <tbody id="liveResultsTable">
          <tr class="live-player-you">
            <td>1</td>
            <td><strong>Você</strong></td>
            <td>0</td>
            <td class="position-prize">R$ 0.08</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <!-- Removemos o botão de atualizar -->
</div>

<!-- Import Supabase SDK -->
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>

<script>
// Sistema de Jogo Snake.io - Versão Premium com Supabase
(() => {
  'use strict';
  
  // --- CONSTANTES E CONFIGURAÇÕES ---
  const CONFIG = {
    FPS: 60,
    GRID_SIZE: 20,
    SNAKE_START_LENGTH: 3,
    BASE_SPEED: 8,
    POWERUP_CHANCE: 0.15,
    CAMERA_SMOOTHING: 0.1,
    FIREBALL_SPEED: 10,
    FIREBALL_DISTANCE: 15,
    FIREBALL_COOLDOWN: 5000,
    LEVEL_UP_SCORE: 500,
    STAR_COUNT: 100,
    MIN_WITHDRAW: 5.00,
    GAME_DURATION: 25000,
    COMPETITION_SIZE: 10,
    PRIZES: [0.08, 0.08, 0.08, 0.08, 0.04, 0.04],
    MAX_WAIT_TIME: 300000,
    AD_URL: "https://data741.click/8947a4f9fdd7efb4f1ec/609321b097/?placementName=default"
  };
  
  // --- ELEMENTOS DO DOM ---
  const canvas = document.getElementById('gameCanvas');
  const ctx = canvas.getContext('2d');
  const panels = {
    auth: document.getElementById('authPanel'),
    main: document.getElementById('mainMenu'),
    profile: document.getElementById('profilePanel'),
    ad: document.getElementById('adPanel'),
    game: document.getElementById('gameContainer'),
    pause: document.getElementById('pausePanel'),
    gameOver: document.getElementById('gameOverPanel'),
    withdraw: document.getElementById('withdrawPanel'),
    history: document.getElementById('historyPanel'),
    results: document.getElementById('resultsPanel')
  };
  
  // --- SUPABASE CONFIGURAÇÃO ---
  const SUPABASE_URL = 'https://kvyproeungotplascwzx.supabase.co';
  const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt2eXByb2V1bmdvdHBsYXNjd3p4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTI0Mzg0NzQsImV4cCI6MjA2ODAxNDQ3NH0.ayXBpDpQPhBW6IZ3mWDLIkGij1Wz9JApRt3dQoJGElU';
  
  // Inicializar Supabase
  const { createClient } = window.supabase;
  const supabaseClient = createClient(SUPABASE_URL, SUPABASE_KEY);
  
  // --- ESTADO DO JOGO ---
  let state = {
    user: {
      id: null,
      name: 'Jogador',
      email: '',
      avatar: 'J',
      balance: 0,
      totalGames: 0,
      highScore: 0,
      totalEarnings: 0,
      totalWithdraws: 0,
      level: 1,
      loggedIn: false,
      isGuest: false,
      competitionHistory: [],
      pendingCompetitions: []
    },
    
    gameRunning: false,
    gamePaused: false,
    gameStartTime: 0,
    gameTimeLeft: CONFIG.GAME_DURATION,
    score: 0,
    level: 1,
    speed: CONFIG.BASE_SPEED,
    direction: 'right',
    nextDirection: 'right',
    snake: [],
    food: null,
    specialFood: null,
    powerups: [],
    obstacles: [],
    activePowerups: {
      shield: { active: false, endTime: 0 },
      turbo: { active: false, endTime: 0 },
      fireball: { active: false, endTime: 0, cooldown: 0 },
      magnet: { active: false, endTime: 0 },
      multiplier: { active: false, endTime: 0, value: 2 }
    },
    lastFrameTime: 0,
    frameCount: 0,
    gridWidth: 0,
    gridHeight: 0,
    particles: [],
    notifications: [],
    lastMoveTime: 0,
    moveInterval: 1000 / CONFIG.BASE_SPEED,
    fireballs: [],
    touchControls: false,
    lastFireballTime: 0,
    stars: [],
    wasAutoPaused: false,
    
    competition: {
      id: null,
      players: [],
      currentPosition: 0,
      prize: 0,
      lastCompetitionId: null,
      lastCompetitionResult: null,
      currentPlayers: 0,
      competitionRef: null,
      competitionListener: null,
      liveCompetitionListener: null,
      livePlayers: []
    },
    
    currentMatch: {
      score: 0,
      startTime: 0,
      endTime: 0,
      status: 'pending'
    },

    adState: {
      watched: [false, false, false, false],
      callback: null
    }
  };

  // Função para gerar UUID
  function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  // --- INICIALIZAÇÃO ---
  function init() {
    try {
      // Simular carregamento progressivo
      let progress = 0;
      const loaderInterval = setInterval(() => {
        progress += Math.random() * 10;
        if (progress >= 100) {
          clearInterval(loaderInterval);
          document.getElementById('loaderProgress').style.width = '100%';
          setTimeout(() => {
            document.getElementById('loader').style.display = 'none';
            checkAuthState();
          }, 500);
        } else {
          document.getElementById('loaderProgress').style.width = `${progress}%`;
        }
      }, 100);
      
      // Criar estrelas de fundo
      createStars();
      
      // Verificar se é um dispositivo touch
      state.touchControls = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
      document.getElementById('touchControls').style.display = state.touchControls ? 'block' : 'none';
      
      // Configurar controles
      setupControls();
      
      // Configurar eventos dos botões
      setupButtons();
      
      // Configurar formulários
      setupForms();
      
      // Configurar barra de navegação
      setupNavbar();
      
      // Atualizar UI
      updateUserUI();
      
      // Adicionar event listeners para pausa automática
      document.addEventListener('visibilitychange', handleVisibilityChange);
      window.addEventListener('blur', handleWindowBlur);
      window.addEventListener('focus', handleWindowFocus);
      
      // Redimensionar o canvas inicialmente
      resizeCanvas();
      
      // Adicionar evento de redimensionamento da janela
      window.addEventListener('resize', resizeCanvas);
      
      // Iniciar loop do jogo
      requestAnimationFrame(gameLoop);
    } catch (error) {
      console.error('Erro na inicialização:', error);
      document.querySelector('.loader-text').textContent = 'Erro ao carregar o jogo. Por favor, recarregue a página.';
      setTimeout(() => {
        document.getElementById('loader').style.display = 'none';
      }, 1000);
    }
  }
  
  // Configurar barra de navegação estilo Instagram
  function setupNavbar() {
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', function() {
        const target = this.getAttribute('data-target');
        
        // Remover classe active de todos os itens
        document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
        // Adicionar classe active ao item clicado
        this.classList.add('active');
        
        // Esconder todas as seções
        document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
        
        // Ativar a barra de menu apenas na tela principal
        const navbar = document.getElementById('bottomNavbar');
        if (target === 'mainMenu') {
          navbar.classList.add('active');
        } else {
          navbar.classList.remove('active');
        }
        
        if (target === 'gameContainer') {
          // Mostrar anúncios antes de iniciar o jogo
          showAdPanel(startGame);
        } else if (target === 'historyPanel') {
          document.getElementById(target).classList.add('active');
          showHistory(); // Carregar histórico quando acessado
        } else if (target) {
          document.getElementById(target).classList.add('active');
        }
      });
    });
  }
  
  // Função para verificar o estado de autenticação
  function checkAuthState() {
    supabaseClient.auth.getSession()
      .then(({ data: { session } }) => {
        if (session && session.user) {
          handleUserLogin(session.user);
        } else {
          state.user.loggedIn = false;
          showPanel('auth');
        }
      })
      .catch((error) => {
        console.error('Erro ao verificar sessão:', error);
        showNotification('Erro ao verificar sessão. Por favor, faça login novamente.', 'danger');
        logout(true);
      });
  }
  
  // Funções para lidar com a visibilidade da janela
  function handleVisibilityChange() {
    if (document.visibilityState === 'hidden' && state.gameRunning && !state.gamePaused) {
      saveGameState();
      pauseGame(false);
      state.wasAutoPaused = true;
    } else if (document.visibilityState === 'visible' && state.wasAutoPaused) {
      state.gamePaused = false;
      state.wasAutoPaused = false;
      hideAllPanels();
    }
  }
  
  function handleWindowBlur() {
    if (state.gameRunning && !state.gamePaused) {
      saveGameState();
      pauseGame(false);
      state.wasAutoPaused = true;
    }
  }
  
  function handleWindowFocus() {
    if (state.gameRunning && state.gamePaused && state.wasAutoPaused) {
      state.gamePaused = false;
      state.wasAutoPaused = false;
      hideAllPanels();
    }
  }
  
  // Função para salvar o estado do jogo
  function saveGameState() {
    try {
      const gameState = {
        gameRunning: state.gameRunning,
        gamePaused: state.gamePaused,
        gameStartTime: state.gameStartTime,
        gameTimeLeft: state.gameTimeLeft,
        score: state.score,
        level: state.level,
        speed: state.speed,
        direction: state.direction,
        nextDirection: state.nextDirection,
        snake: state.snake,
        food: state.food,
        specialFood: state.specialFood,
        powerups: state.powerups,
        obstacles: state.obstacles,
        activePowerups: state.activePowerups,
        particles: state.particles,
        fireballs: state.fireballs,
        lastFireballTime: state.lastFireballTime,
        lastMoveTime: state.lastMoveTime,
        moveInterval: state.moveInterval,
        frameCount: state.frameCount
      };
      
      localStorage.setItem('snakeGameState', JSON.stringify(gameState));
      console.log('Estado do jogo salvo com sucesso');
    } catch (e) {
      console.error('Erro ao salvar estado do jogo:', e);
    }
  }
  
  // Função para carregar o estado do jogo
  function loadGameState() {
    try {
      const savedState = localStorage.getItem('snakeGameState');
      if (savedState) {
        const gameState = JSON.parse(savedState);
        Object.assign(state, gameState);
        resizeCanvas();
        console.log('Estado do jogo carregado com sucesso');
        return true;
      }
    } catch (e) {
      console.error('Erro ao carregar estado do jogo:', e);
      localStorage.removeItem('snakeGameState');
    }
    return false;
  }
  
  function handleUserLogin(user) {
    const displayName = user.user_metadata?.full_name || 
                       (user.email ? user.email.split('@')[0] : 'Jogador');
    const avatar = displayName.charAt(0).toUpperCase();
    
    state.user = {
      ...state.user,
      id: user.id,
      name: displayName,
      email: user.email || '',
      avatar: avatar,
      loggedIn: true,
      isGuest: user.is_anonymous || false
    };
    
    loadUserDataFromSupabase();
    showNotification('Login realizado com sucesso!', 'success');
    updateUserUI();
    showPanel('main');

    // Iniciar verificação periódica de competições pendentes
    setInterval(checkPendingCompetitions, 30000);
  }

  // Função para verificar competições pendentes
  async function checkPendingCompetitions() {
    if (!state.user.loggedIn || state.user.isGuest || !supabaseClient) return;
    
    for (const comp of [...state.user.pendingCompetitions]) {
      try {
        const compId = comp.id;

        const { data: competition, error } = await supabaseClient
          .from('competitions')
          .select('*')
          .eq('id', compId)
          .single();
        
        if (error) {
          console.error('Erro ao buscar competição:', error);
          continue;
        }
        
        if (competition && competition.player_count >= CONFIG.COMPETITION_SIZE) {
          await completeCompetition(competition);
          state.user.pendingCompetitions = state.user.pendingCompetitions.filter(c => c.id !== comp.id);
          saveUserDataToSupabase();
        }
      } catch (err) {
        console.error('Erro ao verificar competição pendente:', err);
      }
    }
  }

  // Função para concluir uma competição
  async function completeCompetition(competition) {
    if (competition.status === 'completed') return;
    
    const players = [...competition.players];
    players.sort((a, b) => b.score - a.score);
    
    for (let i = 0; i < players.length; i++) {
      if (i < CONFIG.PRIZES.length) {
        players[i].prize = CONFIG.PRIZES[i];
      } else {
        players[i].prize = 0;
      }
      players[i].position = i + 1;
    }
    
    const { error } = await supabaseClient
      .from('competitions')
      .update({
        status: 'completed',
        players: players,
        completed_at: new Date().toISOString()
      })
      .eq('id', competition.id);
    
    if (error) {
      console.error('Erro ao concluir competição:', error);
      return;
    }
    
    for (const player of players) {
      if (player.prize > 0) {
        const { data: userData, error: userError } = await supabaseClient
          .from('users')
          .select('balance, total_earnings')
          .eq('id', player.id)
          .single();
        
        if (userError) {
          console.error(`Erro ao buscar dados do usuário ${player.id}:`, userError);
          continue;
        }
        
        const newBalance = (userData.balance || 0) + player.prize;
        const newTotalEarnings = (userData.total_earnings || 0) + player.prize;
        
        await supabaseClient
          .from('users')
          .update({
            balance: newBalance,
            total_earnings: newTotalEarnings
          })
          .eq('id', player.id);
        
        if (player.id === state.user.id) {
          state.user.balance = newBalance;
          state.user.totalEarnings = newTotalEarnings;
          updateUserUI();
        }
      }
    }
    
    const userInCompetition = players.find(p => p.id === state.user.id);
    if (userInCompetition) {
      state.user.pendingCompetitions = state.user.pendingCompetitions.filter(c => c.id !== competition.id);
      
      state.user.competitionHistory.push({
        id: competition.id,
        players: players,
        position: userInCompetition.position,
        prize: userInCompetition.prize,
        score: userInCompetition.score,
        timestamp: new Date().getTime()
      });
      
      saveUserDataToSupabase();
      showNotification(`Competição concluída! Você ficou em ${userInCompetition.position}º lugar e ganhou R$ ${userInCompetition.prize.toFixed(2)}.`, 'success');
    }
  }
  
  function createStars() {
    const starsContainer = document.getElementById('stars');
    starsContainer.innerHTML = '';
    for (let i = 0; i < CONFIG.STAR_COUNT; i++) {
      const star = document.createElement('div');
      star.className = 'star';
      
      const size = Math.random() * 2 + 1;
      const opacity = Math.random() * 0.5 + 0.5;
      const duration = Math.random() * 5 + 3;
      
      star.style.width = `${size}px`;
      star.style.height = `${size}px`;
      star.style.left = `${Math.random() * 100}%`;
      star.style.top = `${Math.random() * 100}%`;
      star.style.setProperty('--opacity', opacity);
      star.style.setProperty('--duration', `${duration}s`);
      
      starsContainer.appendChild(star);
    }
  }
  
  // --- SUPABASE DB FUNCTIONS ---
  function loadUserDataFromSupabase() {
    if (!state.user.loggedIn || state.user.isGuest || !supabaseClient) return;
    
    supabaseClient
      .from('users')
      .select('*')
      .eq('id', state.user.id)
      .single()
      .then(({ data, error }) => {
        if (error) {
          if (error.code === 'PGRST116' || error.message.includes('0 rows')) {
            saveUserDataToSupabase();
          } else {
            console.error('Erro ao carregar dados do usuário:', error);
            showNotification('Erro ao carregar dados do usuário: ' + error.message, 'danger');
          }
          return;
        }
        
        if (data) {
          state.user = {
            ...state.user,
            balance: data.balance || 0,
            totalGames: data.total_games || 0,
            highScore: data.high_score || 0,
            totalEarnings: data.total_earnings || 0,
            totalWithdraws: data.total_withdraws || 0,
            level: data.level || 1,
            competitionHistory: data.competition_history || [],
            pendingCompetitions: data.pending_competitions || []
          };
          
          cleanOldHistory();
          updateUserUI();
        } else {
          saveUserDataToSupabase();
        }
      })
      .catch((error) => {
        console.error('Erro ao carregar dados do usuário:', error);
        showNotification('Erro ao carregar dados do usuário: ' + error.message, 'danger');
      });
  }
  
  function cleanOldHistory() {
    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;
    
    state.user.competitionHistory = state.user.competitionHistory.filter(comp => {
      return now - comp.timestamp < oneDay;
    });
    
    saveUserDataToSupabase();
  }
  
  function saveUserDataToSupabase() {
    if (!state.user.loggedIn || state.user.isGuest || !supabaseClient) return;
    
    const userData = {
      id: state.user.id,
      name: state.user.name,
      email: state.user.email,
      avatar: state.user.avatar,
      balance: state.user.balance,
      total_games: state.user.totalGames,
      high_score: state.user.highScore,
      total_earnings: state.user.totalEarnings,
      total_withdraws: state.user.totalWithdraws,
      level: state.user.level,
      competition_history: state.user.competitionHistory || [],
      pending_competitions: state.user.pendingCompetitions || [],
      last_updated: new Date().toISOString()
    };
    
    supabaseClient
      .from('users')
      .upsert(userData)
      .then(({ error }) => {
        if (error) {
          console.error('Erro ao salvar dados do usuário:', error);
          showNotification('Erro ao salvar dados do usuário: ' + error.message, 'danger');
        }
      });
  }
  
  // Buscar competição existente ou criar nova
  async function joinCompetition(score) {
    if (state.user.isGuest || !supabaseClient) return;
    
    const { data: existingCompetitions, error: competitionError } = await supabaseClient
      .from('competitions')
      .select('*')
      .eq('status', 'waiting')
      .lte('player_count', CONFIG.COMPETITION_SIZE - 1);
    
    if (competitionError) {
      console.error('Erro ao buscar competições:', competitionError);
      showNotification('Erro ao buscar competições', 'danger');
      return;
    }
    
    let competitionId;
    let competitionData;
    
    const validCompetitions = existingCompetitions?.filter(comp => 
      !comp.players.some(p => p.id === state.user.id)
    ) || [];
    
    if (validCompetitions.length > 0) {
      const competition = validCompetitions[0];
      competitionId = competition.id;
      
      const updatedPlayers = [
        ...competition.players,
        {
          id: state.user.id,
          name: state.user.name,
          score: score,
          avatar: state.user.avatar,
          joined_at: new Date().toISOString()
        }
      ];
      
      competitionData = {
        players: updatedPlayers,
        player_count: updatedPlayers.length
      };
      
      await supabaseClient
        .from('competitions')
        .update(competitionData)
        .eq('id', competitionId);
    } else {
      competitionId = generateUUID();
      competitionData = {
        id: competitionId,
        status: 'waiting',
        created_at: new Date().toISOString(),
        players: [{
          id: state.user.id,
          name: state.user.name,
          score: score,
          avatar: state.user.avatar,
          joined_at: new Date().toISOString()
        }],
        player_count: 1
      };
      
      await supabaseClient
        .from('competitions')
        .insert([competitionData]);
    }
    
    const pendingCompetition = {
      id: competitionId,
      score: score,
      timestamp: Date.now()
    };
    
    const alreadyPending = state.user.pendingCompetitions.some(c => c.id === competitionId);
    if (!alreadyPending) {
      state.user.pendingCompetitions.push(pendingCompetition);
    }
    
    saveUserDataToSupabase();
    showNotification('Você entrou em uma competição! Aguarde outros jogadores...', 'info');
    showLiveCompetitionPanel(competitionId, score);
  }
  
  function showLiveCompetitionPanel(competitionId, yourScore) {
    const panel = document.getElementById('liveCompetitionPanel');
    
    panel.innerHTML = `
      <div class="live-competition-header">
        <h2 class="live-competition-title">🏆 Competição Ativa</h2>
        <button id="btnCloseLiveCompetition" class="live-competition-close">&times;</button>
      </div>
      <div class="live-competition-body">
        <div class="players-count">
          Jogadores: <span id="livePlayersCount">1</span>/10
        </div>
        <div class="progress-container">
          <div id="livePlayersProgress" class="progress-bar" style="width: 10%"></div>
        </div>
        
        <h3 style="text-align: center; margin: 15px 0;">Participantes</h3>
        <div class="results-table-container">
          <table class="competition-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Jogador</th>
                <th>Pontos</th>
                <th>Prêmio</th>
              </tr>
            </thead>
            <tbody id="liveResultsTable">
              <tr class="live-player-you">
                <td>1</td>
                <td><strong>Você</strong></td>
                <td>${yourScore}</td>
                <td class="position-prize">R$ 0.08</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    `;
    
    document.getElementById('btnCloseLiveCompetition').onclick = () => panel.style.display = 'none';
    
    panel.style.display = 'block';
    setupLiveUpdates(competitionId);
  }
  
  function setupLiveUpdates(competitionId) {
    const channel = supabaseClient.channel('live-' + competitionId);
    
    channel.on('postgres_changes', {
      event: 'UPDATE',
      schema: 'public',
      table: 'competitions',
      filter: `id=eq.${competitionId}`
    }, payload => {
      updateCompetitionView(payload.new);
    }).subscribe();
    
    // Atualizar automaticamente a cada 5 segundos
    const interval = setInterval(() => {
      supabaseClient
        .from('competitions')
        .select('*')
        .eq('id', competitionId)
        .single()
        .then(({ data }) => {
          if (data) updateCompetitionView(data);
        });
    }, 5000);
    
    document.getElementById('btnCloseLiveCompetition').addEventListener('click', () => {
      clearInterval(interval);
      channel.unsubscribe();
    });
  }
  
  function updateCompetitionView(competition) {
    const players = competition.players || [];
    
    document.getElementById('livePlayersCount').textContent = players.length;
    document.getElementById('livePlayersProgress').style.width = `${(players.length/10)*100}%`;
    
    const tbody = document.getElementById('liveResultsTable');
    tbody.innerHTML = '';
    
    const uniquePlayers = {};
    const filteredPlayers = players.filter(player => {
      if (!uniquePlayers[player.id]) {
        uniquePlayers[player.id] = true;
        return true;
      }
      return false;
    });
    
    filteredPlayers.sort((a, b) => b.score - a.score);
    
    filteredPlayers.forEach((player, index) => {
      const row = document.createElement('tr');
      if (player.id === state.user.id) row.className = 'live-player-you';
      
      let prize = 0;
      if (index < 4) prize = 0.08;
      else if (index < 6) prize = 0.04;
      
      row.innerHTML = `
        <td>${index + 1}</td>
        <td>${player.id === state.user.id ? '<strong>Você</strong>' : player.name}</td>
        <td>${player.score}</td>
        <td class="position-prize">R$ ${prize.toFixed(2)}</td>
      `;
      
      tbody.appendChild(row);
    });
  }
  
  function showCompetitionResults(competition) {
    if (!competition.players || competition.players.length === 0) {
      console.error('Dados da competição inválidos', competition);
      showNotification('Erro ao cargar resultados da competição', 'danger');
      return;
    }
    
    const date = new Date(competition.timestamp);
    const dateStr = `${date.toLocaleDateString()} ${date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
    
    const resultDateEl = document.getElementById('resultDate');
    if (resultDateEl) resultDateEl.textContent = dateStr;
    
    const userPositionEl = document.getElementById('userPosition');
    if (userPositionEl) userPositionEl.textContent = `${competition.position}º`;
    
    const userPrizeEl = document.getElementById('userPrize');
    if (userPrizeEl) userPrizeEl.textContent = competition.prize.toFixed(2);
    
    const tbody = document.getElementById('resultsTable');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    const uniquePlayers = {};
    const filteredPlayers = competition.players.filter(player => {
      if (!uniquePlayers[player.id]) {
        uniquePlayers[player.id] = true;
        return true;
      }
      return false;
    });
    
    filteredPlayers.forEach((player, index) => {
      const tr = document.createElement('tr');
      
      let positionClass = '';
      if (index === 0) positionClass = 'position-1';
      else if (index === 1) positionClass = 'position-2';
      else if (index === 2) positionClass = 'position-3';
      
      const isCurrentPlayer = player.id === state.user.id;
      const nameCell = isCurrentPlayer ? `<strong>${player.name} (Você)</strong>` : player.name;
      
      const score = player.score || 0;
      const prize = player.prize || 0;
      
      tr.innerHTML = `
        <td class="${positionClass}">${index + 1}º</td>
        <td>${nameCell}</td>
        <td>${score}</td>
        <td class="position-prize">R$ ${prize.toFixed(2)}</td>
      `;
      
      tbody.appendChild(tr);
    });
    
    showPanel('results');
  }
  
  // --- FUNÇÕES DO JOGO ---
  function startGame() {
    if (!state.user.loggedIn) return;
    
    // Ocultar a barra de menu
    document.getElementById('bottomNavbar').classList.remove('active');
    
    panels.game.style.display = 'block';
    resizeCanvas();
    
    // Iniciar contagem regressiva de 3 segundos
    startCountdown(3, () => {
      if (loadGameState()) {
        updateHUD();
        state.gameRunning = true;
        state.gamePaused = false;
        return;
      }
      
      if (state.gridWidth < 10 || state.gridHeight < 10) {
        showNotification('A tela é muito pequena para jogar. Amplie a janela ou gire o dispositivo.', 'warning');
        panels.game.style.display = 'none';
        return;
      }
      
      state.gameRunning = true;
      state.gamePaused = false;
      state.gameStartTime = Date.now();
      state.gameTimeLeft = CONFIG.GAME_DURATION;
      state.score = 0,
      state.level = 1,
      state.speed = CONFIG.BASE_SPEED;
      state.direction = 'right';
      state.nextDirection = 'right';
      state.activePowerups = {
        shield: { active: false, endTime: 0 },
        turbo: { active: false, endTime: 0 },
        fireball: { active: false, endTime: 0, cooldown: 0 },
        magnet: { active: false, endTime: 0 },
        multiplier: { active: false, endTime: 0, value: 2 }
      };
      state.powerups = [];
      state.obstacles = [];
      state.particles = [];
      state.fireballs = [];
      state.lastMoveTime = 0;
      state.moveInterval = 1000 / state.speed;
      state.wasAutoPaused = false;
      
      initSnake();
      spawnFood();
      generateObstacles();
      updateHUD();
      hideAllPanels();
    });
  }
  
  // Função para contagem regressiva
  function startCountdown(seconds, callback) {
    let count = seconds;
    const overlay = document.createElement('div');
    overlay.className = 'countdown-overlay';
    document.getElementById('app-container').appendChild(overlay);
    
    const countdown = () => {
      overlay.textContent = count;
      count--;
      
      if (count < 0) {
        overlay.remove();
        callback();
      } else {
        setTimeout(countdown, 1000);
      }
    };
    
    countdown();
  }
  
  function initSnake() {
    state.snake = [];
    const startX = Math.max(5, Math.min(state.gridWidth - 6, Math.floor(state.gridWidth / 2)));
    const startY = Math.max(5, Math.min(state.gridHeight - 6, Math.floor(state.gridHeight / 2)));
    
    for (let i = 0; i < CONFIG.SNAKE_START_LENGTH; i++) {
      state.snake.push({
        x: startX - i,
        y: startY,
        color: i === 0 ? '#00ff88' : '#004422'
      });
    }
  }
  
  function generateObstacles() {
    state.obstacles = [];
    // Aumentar a quantidade de obstáculos (de 100 para 33)
    const obstacleCount = Math.floor((state.gridWidth * state.gridHeight) / 33);
    
    for (let i = 0; i < obstacleCount; i++) {
      let pos;
      let attempts = 0;
      do {
        pos = {
          x: Math.floor(Math.random() * state.gridWidth),
          y: Math.floor(Math.random() * state.gridHeight)
        };
        attempts++;
      } while (isPositionOccupied(pos.x, pos.y) && attempts < 100);
      
      if (attempts < 100) {
        state.obstacles.push(pos);
      }
    }
  }
  
  function spawnFood() {
    let foodPosition;
    let attempts = 0;
    const maxAttempts = 100;
    
    const isSpecial = Math.random() < 0.2;
    
    do {
      foodPosition = {
        x: Math.floor(Math.random() * state.gridWidth),
        y: Math.floor(Math.random() * state.gridHeight),
        isSpecial
      };
      attempts++;
    } while (isPositionOccupied(foodPosition.x, foodPosition.y) && attempts < maxAttempts);
    
    state.food = foodPosition;
    
    if (Math.random() < CONFIG.POWERUP_CHANCE * 0.7) {
      spawnPowerUp();
    }
  }
  
  function isPositionOccupied(x, y) {
    if (state.snake.some(segment => segment.x === x && segment.y === y)) return true;
    if (state.food && state.food.x === x && state.food.y === y) return true;
    if (state.powerups.some(pu => pu.x === x && pu.y === y)) return true;
    if (state.fireballs.some(fb => fb.x === x && fb.y === y)) return true;
    if (state.obstacles.some(obs => obs.x === x && obs.y === y)) return true;
    return false;
  }
  
  function spawnPowerUp() {
    let powerupPosition;
    let attempts = 0;
    const maxAttempts = 100;
    
    const type = getRandomPowerUpType();
    const color = getPowerUpColor(type);
    const icon = getPowerUpIcon(type);
    
    do {
      powerupPosition = {
        x: Math.floor(Math.random() * state.gridWidth),
        y: Math.floor(Math.random() * state.gridHeight),
        type: type,
        color: color,
        icon: icon
      };
      attempts++;
    } while (isPositionOccupied(powerupPosition.x, powerupPosition.y) && attempts < maxAttempts);
    
    if (attempts < maxAttempts) {
      state.powerups.push(powerupPosition);
    }
  }
  
  function getRandomPowerUpType() {
    const types = ['shield', 'turbo', 'fireball', 'magnet', 'multiplier'];
    return types[Math.floor(Math.random() * types.length)];
  }
  
  function getPowerUpColor(type) {
    const colors = {
      shield: '#00ccff',
      turbo: '#ff9900',
      fireball: '#ff4444',
      magnet: '#cc00ff',
      multiplier: '#ffcc00'
    };
    return colors[type] || '#ffffff';
  }
  
  function getPowerUpIcon(type) {
    const icons = {
      shield: '🛡',
      turbo: '⚡',
      fireball: '🔥',
      magnet: '🧲',
      multiplier: '✨'
    };
    return icons[type] || '❓';
  }
  
  function updateGame(deltaTime) {
    if (!state.gameRunning || state.gamePaused) return;
    
    const now = Date.now();
    state.gameTimeLeft = CONFIG.GAME_DURATION - (now - state.gameStartTime);
    
    const timeDisplayEl = document.getElementById('timeDisplay');
    if (timeDisplayEl) timeDisplayEl.textContent = `${Math.ceil(state.gameTimeLeft / 1000)}s`;
    
    if (state.gameTimeLeft <= 0) return gameOver();
    
    updatePowerUps(deltaTime);
    
    if (now - state.lastMoveTime >= state.moveInterval) {
      moveSnake();
      checkCollisions();
      state.lastMoveTime = now;
    }
    
    updateFireballs(deltaTime);
    updateParticles(deltaTime);
    
    state.frameCount++;
  }
  
  function updatePowerUps(deltaTime) {
    const now = Date.now();
    
    if (state.activePowerups.shield.active && now > state.activePowerups.shield.endTime) {
      state.activePowerups.shield.active = false;
      showNotification('Escudo desativado', 'info');
    }
    
    if (state.activePowerups.turbo.active && now > state.activePowerups.turbo.endTime) {
      state.activePowerups.turbo.active = false;
      state.speed = CONFIG.BASE_SPEED;
      state.moveInterval = 1000 / state.speed;
      showNotification('Turbo desativado', 'info');
    }
    
    if (state.activePowerups.fireball.active) {
      if (now > state.activePowerups.fireball.endTime) {
        state.activePowerups.fireball.active = false;
        showNotification('Fireball desativado', 'info');
      } else if (state.activePowerups.fireball.cooldown > 0) {
        state.activePowerups.fireball.cooldown -= deltaTime;
      }
    }
    
    if (state.activePowerups.magnet.active && now > state.activePowerups.magnet.endTime) {
      state.activePowerups.magnet.active = false;
      showNotification('Iman desativado', 'info');
    }
    
    if (state.activePowerups.multiplier.active && now > state.activePowerups.multiplier.endTime) {
      state.activePowerups.multiplier.active = false;
      showNotification('Multiplicador desativado', 'info');
    }
    
    if (state.score >= state.level * CONFIG.LEVEL_UP_SCORE) {
      levelUp();
    }
  }
  
  function levelUp() {
    state.level++;
    showNotification(`Level Up! Nível ${state.level}`, 'success');
    state.speed = CONFIG.BASE_SPEED + Math.floor(state.level / 2);
    state.moveInterval = 1000 / state.speed;
  }
  
  function moveSnake() {
    state.direction = state.nextDirection;
    const head = { ...state.snake[0] };
    
    switch (state.direction) {
      case 'up': head.y--; break;
      case 'down': head.y++; break;
      case 'left': head.x--; break;
      case 'right': head.x++; break;
    }
    
    if (head.x < 0 || head.y < 0 || head.x >= state.gridWidth || head.y >= state.gridHeight) {
      if (!state.activePowerups.shield.active) return gameOver('wall');
      
      if (head.x < 0) head.x = state.gridWidth - 1;
      else if (head.x >= state.gridWidth) head.x = 0;
      if (head.y < 0) head.y = state.gridHeight - 1;
      else if (head.y >= state.gridHeight) head.y = 0;
    }
    
    state.snake.unshift({
      x: head.x,
      y: head.y,
      color: head.color
    });
    
    // CORREÇÃO: Removido o parêntese extra aqui
    if (head.x === state.food.x && head.y === state.food.y) {
      let scoreValue = state.food.isSpecial ? 30 : 10;
      if (state.activePowerups.multiplier.active) scoreValue *= state.activePowerups.multiplier.value;
      state.score += scoreValue;
      
      createParticles({
        x: state.food.x * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2,
        y: state.food.y * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2,
        count: state.food.isSpecial ? 20 : 10,
        color: state.food.isSpecial ? '#ffcc00' : '#ff4444',
        size: state.food.isSpecial ? 5 : 3
      });
      
      createGrowEffect(head.x, head.y);
      spawnFood();
    } else {
      state.snake.pop();
    }
    
    for (let i = 0; i < state.powerups.length; i++) {
      if (head.x === state.powerups[i].x && head.y === state.powerups[i].y) {
        createParticles({
          x: head.x * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2,
          y: head.y * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2,
          count: 15,
          color: state.powerups[i].color,
          size: 4
        });
        
        activatePowerUp(state.powerups[i].type);
        state.powerups.splice(i, 1);
        i--;
      }
    }
    
    if (state.activePowerups.magnet.active && state.food) {
      const head = state.snake[0];
      const dx = state.food.x - head.x;
      const dy = state.food.y - head.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      
      if (distance < 10) {
        const angle = Math.atan2(dy, dx);
        const force = 0.1;
        
        state.food.x -= Math.cos(angle) * force;
        state.food.y -= Math.sin(angle) * force;
        
        state.food.x = Math.round(state.food.x);
        state.food.y = Math.round(state.food.y);
      }
    }
    
    updateSnakeColors();
  }
  
  function updateSnakeColors() {
    for (let i = 0; i < state.snake.length; i++) {
      if (i === 0) state.snake[i].color = '#00ff88';
      else {
        const ratio = i / state.snake.length;
        state.snake[i].color = interpolateColor('#00ff88', '#004422', ratio);
      }
    }
  }
  
  function interpolateColor(color1, color2, ratio) {
    const hexToRgb = hex => {
      const bigint = parseInt(hex.replace('#', ''), 16);
      return {
        r: (bigint >> 16) & 255,
        g: (bigint >> 8) & 255,
        b: bigint & 255
      };
    };
    
    const rgbToHex = rgb => `#${((1 << 24) + (rgb.r << 16) + (rgb.g << 8) + rgb.b).toString(16).slice(1)}`;
    
    const rgb1 = hexToRgb(color1);
    const rgb2 = hexToRgb(color2);
    
    const r = Math.round(rgb1.r + (rgb2.r - rgb1.r) * ratio);
    const g = Math.round(rgb1.g + (rgb2.g - rgb1.g) * ratio);
    const b = Math.round(rgb1.b + (rgb2.b - rgb1.b) * ratio);
    
    return rgbToHex({ r, g, b });
  }
  
  function checkCollisions() {
    const head = state.snake[0];
    
    for (const obs of state.obstacles) {
      if (head.x === obs.x && head.y === obs.y) {
        if (!state.activePowerups.shield.active) return gameOver('obstacle');
        createParticles({
          x: obs.x * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2,
          y: obs.y * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2,
          count: 15,
          color: '#ff6600',
          size: 4
        });
        state.obstacles = state.obstacles.filter(o => o !== obs);
        showNotification('Escudo quebrou o obstáculo!', 'info');
        break;
      }
    }
    
    for (let i = Math.max(3, state.snake.length - 5); i < state.snake.length; i++) {
      if (head.x === state.snake[i].x && head.y === state.snake[i].y) {
        if (!state.activePowerups.shield.active) return gameOver('body');
        state.snake = state.snake.slice(0, i);
        showNotification('Escudo ativado!', 'info');
        break;
      }
    }
  }
  
  function activatePowerUp(type) {
    switch (type) {
      case 'shield':
        state.activePowerups.shield = { active: true, endTime: Date.now() + 10000 };
        showNotification('Escudo ativado!', 'success');
        break;
      case 'turbo':
        state.activePowerups.turbo = { active: true, endTime: Date.now() + 8000 };
        state.speed = CONFIG.BASE_SPEED * 2;
        state.moveInterval = 1000 / state.speed;
        showNotification('Turbo ativado!', 'success');
        break;
      case 'fireball':
        state.activePowerups.fireball = { active: true, endTime: Date.now() + 15000, cooldown: 0 };
        showNotification('Fireball desbloqueado! Toque no ícone 🔥 para atirar', 'success');
        break;
      case 'magnet':
        state.activePowerups.magnet = { active: true, endTime: Date.now() + 15000 };
        showNotification('Iman ativado! A comida será atraída para você', 'success');
        break;
      case 'multiplier':
        state.activePowerups.multiplier = { active: true, endTime: Date.now() + 20000, value: 2 };
        showNotification('Multiplicador ativado! Pontos dobrados', 'success');
        break;
    }
    updateHUD();
  }
  
  function shootFireball() {
    if (!state.activePowerups.fireball.active || state.activePowerups.fireball.cooldown > 0) return;
    
    const head = state.snake[0];
    const fireball = {
      x: head.x,
      y: head.y,
      direction: state.direction,
      distance: 0
    };
    
    state.fireballs.push(fireball);
    state.activePowerups.fireball.cooldown = CONFIG.FIREBALL_COOLDOWN;
    state.lastFireballTime = Date.now();
    
    createParticles({
      x: head.x * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2,
      y: head.y * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2,
      count: 10,
      color: '#ff6600',
      size: 4
    });
  }
  
  function updateFireballs(deltaTime) {
    for (let i = state.fireballs.length - 1; i >= 0; i--) {
      const fb = state.fireballs[i];
      
      switch (fb.direction) {
        case 'up': fb.y--; break;
        case 'down': fb.y++; break;
        case 'left': fb.x--; break;
        case 'right': fb.x++; break;
      }
      
      fb.distance++;
      
      if (fb.x < 0 || fb.y < 0 || fb.x >= state.gridWidth || fb.y >= state.gridHeight || fb.distance >= CONFIG.FIREBALL_DISTANCE) {
        state.fireballs.splice(i, 1);
      }
    }
  }
  
  function createGrowEffect(x, y) {
    const effect = document.createElement('div');
    effect.className = 'grow-effect';
    effect.style.left = `${x * CONFIG.GRID_SIZE}px`;
    effect.style.top = `${y * CONFIG.GRID_SIZE}px`;
    effect.style.width = `${CONFIG.GRID_SIZE * 2}px`;
    effect.style.height = `${CONFIG.GRID_SIZE * 2}px`;
    
    document.getElementById('effectsLayer').appendChild(effect);
    
    setTimeout(() => {
      effect.style.transition = 'transform 0.5s ease-out, opacity 0.5s ease-out';
      effect.style.transform = 'scale(3)';
      effect.style.opacity = '0';
      
      setTimeout(() => effect.remove(), 500);
    }, 10);
  }
  
  function createDeathEffect(x, y) {
    const effect = document.createElement('div');
    effect.className = 'death-effect';
    effect.style.left = `${x * CONFIG.GRID_SIZE}px`;
    effect.style.top = `${y * CONFIG.GRID_SIZE}px`;
    effect.style.width = `${CONFIG.GRID_SIZE * 3}px`;
    effect.style.height = `${CONFIG.GRID_SIZE * 3}px`;
    
    document.getElementById('effectsLayer').appendChild(effect);
    
    setTimeout(() => {
      effect.style.transition = 'transform 0.5s ease-out, opacity 0.5s ease-out';
      effect.style.transform = 'scale(5)';
      effect.style.opacity = '0';
      
      setTimeout(() => effect.remove(), 500);
    }, 10);
  }
  
  function gameOver(reason) {
    state.gameRunning = false;
    panels.game.style.display = 'none';
    
    createParticles({
      x: state.snake[0].x * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2,
      y: state.snake[0].y * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2,
      count: 30,
      color: '#ff4444',
      size: 4
    });
    
    createDeathEffect(state.snake[0].x, state.snake[0].y);
    
    state.user.totalGames++;
    const isNewHighscore = state.score > state.user.highScore;
    if (isNewHighscore) state.user.highScore = state.score;
    
    localStorage.removeItem('snakeGameState');
    
    showAdPanel(() => {
      const finalScoreEl = document.getElementById('finalScore');
      if (finalScoreEl) finalScoreEl.textContent = state.score;
      
      if (!state.user.isGuest) joinCompetition(state.score);
      
      updateUserUI();
      showPanel('gameOver');
    });
  }

  function pauseGame(isManual = true) {
    if (!state.gameRunning) return;
    
    if (state.gamePaused && isManual) {
      state.gamePaused = false;
      hideAllPanels();
      state.wasAutoPaused = false;
      return;
    }

    if (!state.gamePaused) {
      state.gamePaused = true;
      saveGameState();

      if (isManual) {
        const pauseScoreEl = document.getElementById('pauseScore');
        if (pauseScoreEl) pauseScoreEl.textContent = state.score;
        
        const pauseTimeEl = document.getElementById('pauseTime');
        if (pauseTimeEl) pauseTimeEl.textContent = `${Math.ceil(state.gameTimeLeft / 1000)}s`;
        
        showPanel('pause');
      } else {
        showNotification('Jogo pausado (você saiu da tela)', 'info');
      }
    }
  }

  // --- RENDERIZAÇÃO ---
  function render() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    if (state.gameRunning && !state.gamePaused) drawGrid();
    if (state.gameRunning) {
      drawFood();
      drawPowerUps();
      drawSnake();
      drawFireballs();
      drawParticles();
      drawObstacles();
    }
    if (state.gamePaused) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = 'white';
      ctx.font = 'bold 48px var(--font-family)';
      ctx.textAlign = 'center';
      ctx.fillText('PAUSADO', canvas.width / 2, canvas.height / 2);
    }
  }
  
  function drawObstacles() {
    for (const obs of state.obstacles) {
      const x = obs.x * CONFIG.GRID_SIZE;
      const y = obs.y * CONFIG.GRID_SIZE;
      ctx.fillStyle = '#666666';
      ctx.fillRect(x, y, CONFIG.GRID_SIZE, CONFIG.GRID_SIZE);
      
      ctx.strokeStyle = '#444444';
      ctx.lineWidth = 1;
      ctx.strokeRect(x, y, CONFIG.GRID_SIZE, CONFIG.GRID_SIZE);
      ctx.beginPath();
      ctx.moveTo(x, y + CONFIG.GRID_SIZE / 2);
      ctx.lineTo(x + CONFIG.GRID_SIZE, y + CONFIG.GRID_SIZE / 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x + CONFIG.GRID_SIZE / 2, y);
      ctx.lineTo(x + CONFIG.GRID_SIZE / 2, y + CONFIG.GRID_SIZE);
      ctx.stroke();
    }
  }
  
  function drawGrid() {
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 0.5;
    
    for (let x = 0; x <= canvas.width; x += CONFIG.GRID_SIZE) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    
    for (let y = 0; y <= canvas.height; y += CONFIG.GRID_SIZE) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }
  }
  
  function drawRoundedRect(ctx, x, y, width, height, radius) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
    ctx.fill();
  }
  
  function drawSnake() {
    for (let i = 0; i < state.snake.length; i++) {
      const segment = state.snake[i];
      const size = CONFIG.GRID_SIZE * (i === 0 ? 0.9 : 0.8);
      const offset = (CONFIG.GRID_SIZE - size) / 2;
      
      ctx.fillStyle = segment.color;
      
      if (i === 0) {
        const centerX = segment.x * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2;
        const centerY = segment.y * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2;
        
        ctx.beginPath();
        ctx.arc(centerX, centerY, size / 2, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = 'white';
        
        let eye1X, eye1Y, eye2X, eye2Y;
        const eyeOffset = size * 0.2;
        const eyeSize = size * 0.15;
        
        switch (state.direction) {
          case 'up':
            eye1X = centerX - eyeOffset;
            eye1Y = centerY - eyeOffset;
            eye2X = centerX + eyeOffset;
            eye2Y = centerY - eyeOffset;
            break;
          case 'down':
            eye1X = centerX - eyeOffset;
            eye1Y = centerY + eyeOffset;
            eye2X = centerX + eyeOffset;
            eye2Y = centerY + eyeOffset;
            break;
          case 'left':
            eye1X = centerX - eyeOffset;
            eye1Y = centerY - eyeOffset;
            eye2X = centerX - eyeOffset;
            eye2Y = centerY + eyeOffset;
            break;
          case 'right':
            eye1X = centerX + eyeOffset;
            eye1Y = centerY - eyeOffset;
            eye2X = centerX + eyeOffset;
            eye2Y = centerY + eyeOffset;
            break;
        }
        
        ctx.beginPath();
        ctx.arc(eye1X, eye1Y, eyeSize, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(eye2X, eye2Y, eyeSize, 0, Math.PI * 2);
        ctx.fill();
      } else {
        drawRoundedRect(
          ctx, 
          segment.x * CONFIG.GRID_SIZE + offset, 
          segment.y * CONFIG.GRID_SIZE + offset, 
          size, 
          size, 
          size / 2
        );
      }
    }
    
    if (state.activePowerups.shield.active) {
      const head = state.snake[0];
      ctx.strokeStyle = 'rgba(0, 204, 255, 0.7)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(head.x * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2, head.y * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2, CONFIG.GRID_SIZE * 0.7, 0, Math.PI * 2);
      ctx.stroke();
    }
  }
  
  function drawFireballs() {
    for (const fb of state.fireballs) {
      const centerX = fb.x * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2;
      const centerY = fb.y * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2;
      const size = CONFIG.GRID_SIZE * 0.6;
      
      const gradient = ctx.createRadialGradient(centerX, centerY, size * 0.2, centerX, centerY, size);
      gradient.addColorStop(0, '#ffcc00');
      gradient.addColorStop(0.5, '#ff6600');
      gradient.addColorStop(1, '#ff3300');
      
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(centerX, centerY, size, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.fillStyle = 'rgba(255, 204, 0, 0.3)';
      ctx.beginPath();
      ctx.arc(centerX, centerY, size * 1.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  
  function drawFood() {
    if (!state.food) return;
    
    const centerX = state.food.x * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2;
    const centerY = state.food.y * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2;
    const size = CONFIG.GRID_SIZE * 0.7;
    
    if (state.food.isSpecial) {
      const pulseSize = size * (1 + Math.sin(Date.now() / 200) * 0.2);
      
      ctx.fillStyle = 'rgba(255, 204, 0, 0.3)';
      ctx.beginPath();
      ctx.arc(centerX, centerY, pulseSize * 1.5, 0, Math.PI * 2);
      ctx.fill();
      
      const gradient = ctx.createRadialGradient(centerX, centerY, size * 0.3, centerX, centerY, size);
      gradient.addColorStop(0, '#ffcc00');
      gradient.addColorStop(1, '#ff9900');
      
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(centerX, centerY, pulseSize, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.fillStyle = '#ff6600';
      ctx.beginPath();
      ctx.arc(centerX - size * 0.3, centerY - size * 0.2, size * 0.1, 0, Math.PI * 2);
      ctx.arc(centerX + size * 0.3, centerY - size * 0.2, size * 0.1, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.beginPath();
      ctx.arc(centerX, centerY + size * 0.2, size * 0.2, 0, Math.PI);
      ctx.strokeStyle = '#ff6600';
      ctx.lineWidth = 2;
      ctx.stroke();
    } else {
      ctx.fillStyle = '#ff4444';
      ctx.beginPath();
      ctx.arc(centerX, centerY, size, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.fillStyle = '#cc0000';
      ctx.beginPath();
      ctx.arc(centerX - size * 0.3, centerY - size * 0.2, size * 0.1, 0, Math.PI * 2);
      ctx.arc(centerX + size * 0.3, centerY - size * 0.2, size * 0.1, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.beginPath();
      ctx.arc(centerX, centerY + size * 0.2, size * 0.2, 0, Math.PI);
      ctx.strokeStyle = '#cc0000';
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  }
  
  function drawPowerUps() {
    for (const powerup of state.powerups) {
      const centerX = powerup.x * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2;
      const centerY = powerup.y * CONFIG.GRID_SIZE + CONFIG.GRID_SIZE / 2;
      const size = CONFIG.GRID_SIZE * 0.7;
      
      if (state.frameCount % 30 < 15) {
        const r = parseInt(powerup.color.slice(1,3), 16);
        const g = parseInt(powerup.color.slice(3,5), 16);
        const b = parseInt(powerup.color.slice(5,7), 16);
        ctx.fillStyle = `rgba(${r}, ${g}, ${b}, 0.2)`;
        ctx.beginPath();
        ctx.arc(centerX, centerY, size * 1.5, 0, Math.PI * 2);
        ctx.fill();
      }
      
      ctx.fillStyle = powerup.color;
      ctx.beginPath();
      ctx.arc(centerX, centerY, size, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.fillStyle = 'white';
      ctx.font = `bold ${size}px Arial`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(powerup.icon, centerX, centerY);
    }
  }
  
  function createParticles(options) {
    const { x, y, count = 10, color = '#ffffff', size = 3, speed = 2, lifespan = 60 } = options;
    
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const velocity = Math.random() * speed;
      
      state.particles.push({
        x,
        y,
        vx: Math.cos(angle) * velocity,
        vy: Math.sin(angle) * velocity,
        color,
        size: Math.random() * size + size * 0.5,
        life: lifespan,
        maxLife: lifespan,
        decay: 0.95 + Math.random() * 0.04
      });
    }
  }
  
  function updateParticles(deltaTime) {
    for (let i = state.particles.length - 1; i >= 0; i--) {
      const p = state.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.05;
      p.life--;
      p.size *= p.decay;
      
      if (p.life <= 0 || p.size < 0.5) state.particles.splice(i, 1);
    }
  }
  
  function drawParticles() {
    for (const p of state.particles) {
      const alpha = p.life / p.maxLife;
      const r = parseInt(p.color.slice(1,3), 16);
      const g = parseInt(p.color.slice(3,5), 16);
      const b = parseInt(p.color.slice(5,7), 16);
      ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${alpha})`;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  
  // --- INTERFACE DO USUÁRIO ---
  function updateHUD() {
    const scoreDisplayEl = document.getElementById('scoreDisplay');
    if (scoreDisplayEl) scoreDisplayEl.textContent = state.score;
  }
  
  function showPanel(panelName) {
    hideAllPanels();
    if (panelName === 'main') {
      // Ativar a barra de menu na tela principal
      document.getElementById('bottomNavbar').classList.add('active');
      updateUserUI();
    } else {
      // Desativar a barra de menu em outras telas
      document.getElementById('bottomNavbar').classList.remove('active');
    }
    if (panels[panelName]) panels[panelName].classList.add('active');
  }
  
  function hideAllPanels() {
    for (const panel of Object.values(panels)) panel.classList.remove('active');
  }
  
  function showNotification(message, type = 'info') {
    const notification = document.getElementById('notification');
    if (!notification) return;
    
    notification.textContent = message;
    notification.className = `notification ${type}`;
    notification.classList.add('show');
    
    setTimeout(() => notification.classList.remove('show'), 3000);
  }
  
  // --- CONTROLES ---
  function setupControls() {
    window.addEventListener('keydown', e => {
      if (!state.gameRunning || state.gamePaused) return;
      
      switch (e.key) {
        case 'ArrowUp': if (state.direction !== 'down') state.nextDirection = 'up'; e.preventDefault(); break;
        case 'ArrowDown': if (state.direction !== 'up') state.nextDirection = 'down'; e.preventDefault(); break;
        case 'ArrowLeft': if (state.direction !== 'right') state.nextDirection = 'left'; e.preventDefault(); break;
        case 'ArrowRight': if (state.direction !== 'left') state.nextDirection = 'right'; e.preventDefault(); break;
        case ' ': 
          if (state.activePowerups.fireball.active && state.activePowerups.fireball.cooldown <= 0) shootFireball();
          e.preventDefault();
          break;
        case 'Escape': pauseGame(true); e.preventDefault(); break;
      }
    });
    
    let touchStartX = 0;
    let touchStartY = 0;
    
    canvas.addEventListener('touchstart', e => {
      if (!state.gameRunning || state.gamePaused) return;
      if (e.cancelable) {
        e.preventDefault();
      }
      touchStartX = e.touches[0].clientX;
      touchStartY = e.touches[0].clientY;
    }, { passive: false });
    
    canvas.addEventListener('touchmove', e => {
      if (e.cancelable) {
        e.preventDefault();
      }
    }, { passive: false });
    
    canvas.addEventListener('touchend', e => {
      if (!state.gameRunning || state.gamePaused) return;
      const touchEndX = e.changedTouches[0].clientX;
      const touchEndY = e.changedTouches[0].clientY;
      const dx = touchEndX - touchStartX;
      const dy = touchEndY - touchStartY;
      
      if (Math.abs(dx) > Math.abs(dy)) {
        if (dx > 0 && state.direction !== 'left') state.nextDirection = 'right';
        else if (dx < 0 && state.direction !== 'right') state.nextDirection = 'left';
      } else {
        if (dy > 0 && state.direction !== 'up') state.nextDirection = 'down';
        else if (dy < 0 && state.direction !== 'down') state.nextDirection = 'up';
      }
      if (e.cancelable) {
        e.preventDefault();
      }
    }, { passive: false });
    
    document.querySelectorAll('.touch-zone').forEach(zone => {
      zone.addEventListener('touchstart', e => {
        if (!state.gameRunning || state.gamePaused) return;
        const direction = e.target.getAttribute('data-direction');
        if (direction === 'up' && state.direction !== 'down') state.nextDirection = 'up';
        else if (direction === 'down' && state.direction !== 'up') state.nextDirection = 'down';
        else if (direction === 'left' && state.direction !== 'right') state.nextDirection = 'left';
        else if (direction === 'right' && state.direction !== 'left') state.nextDirection = 'right';
        if (e.cancelable) {
          e.preventDefault();
        }
      }, { passive: false });
    });
    
    const btnPause = document.getElementById('btnPause');
    if (btnPause) btnPause.addEventListener('click', () => pauseGame(true));
  }
  
  function setupButtons() {
    const btnSaque = document.getElementById('btnSaque');
    if (btnSaque) btnSaque.addEventListener('click', showWithdrawPanel);
    
    const btnBackFromHistory = document.getElementById('btnBackFromHistory');
    if (btnBackFromHistory) btnBackFromHistory.addEventListener('click', () => showPanel('main'));
    
    const btnResume = document.getElementById('btnResume');
    if (btnResume) btnResume.addEventListener('click', () => pauseGame(true));
    
    const btnQuit = document.getElementById('btnQuit');
    if (btnQuit) btnQuit.addEventListener('click', () => {
      state.gameRunning = false;
      panels.game.style.display = 'none';
      showPanel('main');
    });
    
    const btnBackToMenu = document.getElementById('btnBackToMenu');
    if (btnBackToMenu) btnBackToMenu.addEventListener('click', () => showPanel('main'));
    
    const btnSubmitWithdraw = document.getElementById('btnSubmitWithdraw');
    if (btnSubmitWithdraw) btnSubmitWithdraw.addEventListener('click', submitWithdraw);
    
    const btnCancelWithdraw = document.getElementById('btnCancelWithdraw');
    if (btnCancelWithdraw) btnCancelWithdraw.addEventListener('click', () => showPanel('main'));
    
    const btnLogout = document.getElementById('btnLogout');
    if (btnLogout) btnLogout.addEventListener('click', () => logout());
    
    const googleLoginBtn = document.getElementById('googleLoginBtn');
    if (googleLoginBtn) googleLoginBtn.addEventListener('click', loginWithGoogle);
    
    const googleRegisterBtn = document.getElementById('googleRegisterBtn');
    if (googleRegisterBtn) googleRegisterBtn.addEventListener('click', loginWithGoogle);
    
    const guestLoginBtn = document.getElementById('guestLoginBtn');
    if (guestLoginBtn) guestLoginBtn.addEventListener('click', loginAsGuest);
    
    const btnCloseResults = document.getElementById('btnCloseResults');
    if (btnCloseResults) btnCloseResults.addEventListener('click', () => showPanel('main'));
    
    const btnCloseLiveCompetition = document.getElementById('btnCloseLiveCompetition');
    if (btnCloseLiveCompetition) btnCloseLiveCompetition.addEventListener('click', () => document.getElementById('liveCompetitionPanel').style.display = 'none');
    
    // Botão Jogar para iniciar o jogo após os anúncios
    const btnStartGame = document.getElementById('btnStartGame');
    if (btnStartGame) {
      btnStartGame.addEventListener('click', function() {
        hideAllPanels();
        if (state.adState.callback) {
          state.adState.callback();
        }
      });
    }
    
    document.querySelectorAll('.ad-item').forEach(item => {
      item.addEventListener('click', function() {
        const adIndex = parseInt(this.dataset.ad) - 1;
        // Abrir em nova aba
        const adWindow = window.open(CONFIG.AD_URL, '_blank');
        
        // Verificar periodicamente se o usuário voltou
        const checkFocus = setInterval(() => {
          if (document.hasFocus() && !adWindow.closed) {
            clearInterval(checkFocus);
            // Usuário voltou, aguardar 2 segundos
            setTimeout(() => {
              state.adState.watched[adIndex] = true;
              updateAdButtons();
              
              const watchedCount = state.adState.watched.filter(w => w).length;
              document.getElementById('adStatus').textContent = `Aguardando anúncios... (${watchedCount}/4)`;
              
              // Quando todos os anúncios forem assistidos, mostrar o botão Jogar
              if (watchedCount === 4) {
                document.getElementById('btnStartGame').style.display = 'block';
                document.getElementById('adStatus').textContent = 'Todos os anúncios assistidos! Clique em JOGAR para começar.';
              }
            }, 2000); // Aguardar 2 segundos após voltar
          }
        }, 500);
      });
    });
    
    document.querySelectorAll('.competition-tab').forEach(tab => {
      tab.addEventListener('click', function() {
        document.querySelectorAll('.competition-tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.competition-content').forEach(c => c.classList.remove('active'));
        
        this.classList.add('active');
        
        const tabName = this.dataset.tab;
        document.getElementById(`${tabName}Competitions`).classList.add('active');
      });
    });
  }
  
  function showAdPanel(callback) {
    state.adState.watched = [false, false, false, false];
    state.adState.callback = callback;
    updateAdButtons();
    document.getElementById('adStatus').textContent = 'Aguardando anúncios... (0/4)';
    // Esconder o botão Jogar ao abrir o painel de anúncios
    document.getElementById('btnStartGame').style.display = 'none';
    showPanel('ad');
  }
  
  function updateAdButtons() {
    document.querySelectorAll('.ad-item').forEach((item, index) => {
      if (state.adState.watched[index]) {
        item.style.opacity = '0.6';
        item.innerHTML = `
          <div class="ad-number">${index + 1}</div>
          <div class="ad-text">Assistido ✓</div>
        `;
      } else {
        item.style.opacity = '1';
        item.innerHTML = `
          <div class="ad-number">${index + 1}</div>
          <div class="ad-text">Clique para assistir</div>
        `;
      }
    });
  }
  
  function setupForms() {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
      loginForm.addEventListener('submit', e => {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        login(email, password);
      });
    }
    
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
      registerForm.addEventListener('submit', e => {
        e.preventDefault();
        const name = document.getElementById('registerName').value;
        const email = document.getElementById('registerEmail').value;
        const password = document.getElementById('registerPassword').value;
        const confirmPassword = document.getElementById('registerConfirmPassword').value;
        register(name, email, password, confirmPassword);
      });
    }
    
    document.querySelectorAll('.auth-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.auth-content').forEach(c => c.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById(`${tab.dataset.tab}Content`).classList.add('active');
      });
    });
  }
  
  // --- SISTEMA DE SAQUE ---
  function showWithdrawPanel() {
    document.getElementById('withdrawBalance').textContent = state.user.balance.toFixed(2);
    document.getElementById('withdrawAmount').value = Math.max(CONFIG.MIN_WITHDRAW, state.user.balance).toFixed(2);
    document.getElementById('withdrawAmount').min = CONFIG.MIN_WITHDRAW;
    document.getElementById('withdrawAmount').max = state.user.balance.toFixed(2);
    showPanel('withdraw');
  }
  
  function submitWithdraw() {
    if (state.user.isGuest || !supabaseClient) {
      showNotification('Convidados não podem sacar', 'warning');
      return;
    }
    
    const amountElement = document.getElementById('withdrawAmount');
    const methodElement = document.getElementById('withdrawMethod');
    if (!amountElement || !methodElement) {
      showNotification('Erro no formulário', 'danger');
      return;
    }
    
    const amount = parseFloat(amountElement.value);
    const method = methodElement.value;
    
    if (amount < CONFIG.MIN_WITHDRAW) {
      showNotification(`Valor mínimo para saque é R$ ${CONFIG.MIN_WITHDRAW.toFixed(2)}`, 'warning');
      return;
    }
    
    if (amount > state.user.balance) {
      showNotification('Saldo insuficiente', 'danger');
      return;
    }
    
    if (!method) {
      showNotification('Selecione um método de pagamento', 'warning');
      return;
    }
    
    let paymentInfo = {};
    
    if (method === 'pix') {
      const pixKey = document.getElementById('pixKey')?.value;
      if (!pixKey) {
        showNotification('Informe a chave PIX', 'warning');
        return;
      }
      paymentInfo = { pixKey };
    } else if (method === 'paypal') {
      const paypalEmail = document.getElementById('paypalEmail')?.value;
      if (!paypalEmail) {
        showNotification('Informe o e-mail do PayPal', 'warning');
        return;
      }
      paymentInfo = { paypalEmail };
    } else if (method === 'bank') {
      const bankName = document.getElementById('bankName')?.value;
      const accountType = document.getElementById('accountType')?.value;
      const accountNumber = document.getElementById('accountNumber')?.value;
      const agencyNumber = document.getElementById('agencyNumber')?.value;
      const accountHolder = document.getElementById('accountHolder')?.value;
      const cpf = document.getElementById('cpf')?.value;
      
      if (!bankName || !accountNumber || !agencyNumber || !accountHolder || !cpf) {
        showNotification('Preencha todos os dados bancários', 'warning');
        return;
      }
      
      paymentInfo = { bankName, accountType, accountNumber, agencyNumber, accountHolder, cpf };
    }
    
    const withdrawData = {
      user_id: state.user.id,
      amount: amount,
      method: method,
      payment_info: paymentInfo,
      status: 'pending',
      requested_at: new Date().toISOString()
    };
    
    supabaseClient
      .from('withdrawals')
      .insert([withdrawData])
      .then(({ error }) => {
        if (error) {
          console.error('Erro ao registrar saque:', error);
          showNotification('Erro ao solicitar saque', 'danger');
          return;
        }
        
        state.user.balance -= amount;
        state.user.totalWithdraws += amount;
        saveUserDataToSupabase();
        updateUserUI();
        showNotification(`Saque de R$ ${amount.toFixed(2)} solicitado com sucesso!`, 'success');
        hideAllPanels();
        showPanel('main');
      });
  }
  
  // --- HISTÓRIO DE COMPETIÇÕES ---
  function showHistory() {
    const completedList = document.getElementById('completedHistoryList');
    const pendingList = document.getElementById('pendingHistoryList');
    if (!completedList || !pendingList) {
      console.error("Elementos de histórico não encontrados!");
      return;
    }

    completedList.innerHTML = '';
    pendingList.innerHTML = '';
    
    if (state.user.competitionHistory?.length > 0) {
      state.user.competitionHistory.forEach(comp => {
        const entry = document.createElement('div');
        entry.className = 'history-entry';
        
        const date = new Date(comp.timestamp);
        const dateStr = `${date.toLocaleDateString()} ${date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
        
        entry.innerHTML = `
          <div>
            <div class="history-date">${dateStr}</div>
            <div>Pontuação: ${comp.score}</div>
          </div>
          <div>
            <div class="history-position">${comp.position}º</div>
            <div class="history-prize">R$ ${(comp.prize || 0).toFixed(2)}</div>
          </div>
        `;
        
        const btn = document.createElement('button');
        btn.className = 'btn btn-secondary btn-small';
        btn.innerHTML = '<i class="fas fa-eye"></i>';
        btn.onclick = () => showCompetitionResults(comp);
        entry.appendChild(btn);
        
        completedList.appendChild(entry);
      });
    } else {
      completedList.innerHTML = '<div class="waiting-message">Nenhuma competição concluída</div>';
    }
    
    if (state.user.pendingCompetitions?.length > 0) {
      state.user.pendingCompetitions.forEach(comp => {
        const entry = document.createElement('div');
        entry.className = 'history-entry';
        
        const date = new Date(comp.timestamp);
        const dateStr = `${date.toLocaleDateString()} ${date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
        
        entry.innerHTML = `
          <div>
            <div class="history-date">${dateStr}</div>
            <div>Pontuação: ${comp.score}</div>
          </div>
          <div>
            <div class="history-position">Processando...</div>
          </div>
        `;
        
        const btn = document.createElement('button');
        btn.className = 'btn btn-secondary btn-small';
        btn.innerHTML = '<i class="fas fa-eye"></i>';
        btn.onclick = () => showLiveCompetitionPanel(comp.id, comp.score);
        entry.appendChild(btn);
        
        pendingList.appendChild(entry);
      });
    } else {
      pendingList.innerHTML = '<div class="waiting-message">Nenhuma competição pendente</div>';
    }
  }
  
  // --- LOOP PRINCIPAL ---
  function gameLoop(timestamp) {
    try {
      const deltaTime = timestamp - (state.lastFrameTime || timestamp);
      state.lastFrameTime = timestamp;
      
      if (state.gameRunning) {
        updateGame(deltaTime);
        render();
      }
      
      requestAnimationFrame(gameLoop);
    } catch (error) {
      console.error('Erro no game loop:', error);
      console.error('Detalhes do erro:', error.message, error.stack);
      showNotification('Ocorreu um erro no jogo. Recarregue a página.', 'danger');
    }
  }
  
  // --- FUNÇÕES AUXILIARES ---
  function resizeCanvas() {
    const gameContainer = document.getElementById('gameContainer');
    if (!gameContainer) {
      console.error("Container do jogo não encontrado!");
      return;
    }
    
    const containerWidth = gameContainer.clientWidth;
    const containerHeight = gameContainer.clientHeight;
    
    state.gridWidth = Math.floor(containerWidth / CONFIG.GRID_SIZE);
    state.gridHeight = Math.floor(containerHeight / CONFIG.GRID_SIZE);
    
    canvas.width = state.gridWidth * CONFIG.GRID_SIZE;
    canvas.height = state.gridHeight * CONFIG.GRID_SIZE;
    
    console.log("Canvas redimensionado:", canvas.width, canvas.height);
  }
  
  function updateUserUI() {
    document.getElementById('userName').textContent = state.user.name;
    document.getElementById('statusLevel').textContent = state.user.level;
    document.getElementById('statusBalance').textContent = state.user.balance.toFixed(2);
    document.getElementById('saldoDisplay').textContent = state.user.balance.toFixed(2);
    document.getElementById('totalGames').textContent = state.user.totalGames;
    document.getElementById('highScore').textContent = state.user.highScore;
    document.getElementById('totalEarnings').textContent = state.user.totalEarnings.toFixed(2);
    document.getElementById('totalWithdraws').textContent = state.user.totalWithdraws.toFixed(2);
    
    // Atualizar perfil
    document.getElementById('profileAvatar').textContent = state.user.avatar;
    document.getElementById('profileUserName').textContent = state.user.name;
    document.getElementById('profileUserEmail').textContent = state.user.email || 'email@exemplo.com';
    document.getElementById('profileBalance').textContent = state.user.balance.toFixed(2);
    document.getElementById('profileTotalGames').textContent = state.user.totalGames;
    document.getElementById('profileHighScore').textContent = state.user.highScore;
    document.getElementById('profileTotalEarnings').textContent = state.user.totalEarnings.toFixed(2);
    document.getElementById('profileTotalWithdraws').textContent = state.user.totalWithdraws.toFixed(2);
  }
  
  function login(email, password) {
    supabaseClient.auth.signInWithPassword({ email, password })
      .then(({ data: { user }, error }) => {
        if (error) throw error;
        handleUserLogin(user);
      })
      .catch(error => {
        console.error('Erro ao fazer login:', error);
        showNotification('Erro ao fazer login: ' + error.message, 'danger');
      });
  }
  
  function register(name, email, password, confirmPassword) {
    if (password !== confirmPassword) {
      showNotification('As senhas não coincidem', 'warning');
      return;
    }
    
    supabaseClient.auth.signUp({ email, password, options: { data: { full_name: name } } })
      .then(({ data: { user }, error }) => {
        if (error) throw error;
        showNotification('Cadastro realizado! Verifique seu e-mail para confirmar.', 'success');
        document.querySelector('[data-tab="login"]').click();
      })
      .catch(error => {
        console.error('Erro ao cadastrar:', error);
        showNotification('Erro ao cadastrar: ' + error.message, 'danger');
      });
  }
  
  function loginWithGoogle() {
    supabaseClient.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: window.location.href
      }
    });
  }
  
  function loginAsGuest() {
    state.user = {
      ...state.user,
      name: 'Convidado',
      avatar: 'C',
      loggedIn: true,
      isGuest: true
    };
    updateUserUI();
    showPanel('main');
    showNotification('Você está jogando como convidado. Seus dados não serão salvos.', 'info');
  }
  
  function logout(force = false) {
    localStorage.removeItem('sb_session');
    localStorage.removeItem('snakeGameState');
    
    if (!force && supabaseClient) {
      supabaseClient.auth.signOut();
    }
    
    state.user = {
      id: null,
      name: 'Jogador',
      email: '',
      avatar: 'J',
      balance: 0,
      totalGames: 0,
      highScore: 0,
      totalEarnings: 0,
      totalWithdraws: 0,
      level: 1,
      loggedIn: false,
      isGuest: false,
      competitionHistory: [],
      pendingCompetitions: []
    };
    
    showPanel('auth');
  }
  
  // --- INICIAR JOGO ---
  init();
})();
</script>
</body>
</html>